<?php
include 'db.php';
  if(isset($_POST['sub'])){
     $name = $_POST['name'];
     $email = $_POST['email'];
     $dept = $_POST['dept'];

     //insert 
     $in = "INSERT INTO student(name,email,dept) VALUES('$name','$email','$dept')";
     $ex = mysqli_query($connect,$in);
     if($ex){
        echo "<script>alert('data  insert success')</script>";
       
    }else{
        echo "<script>alert('data insert failed')</script>";
    }
  
  }
 

?>




<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Document</title>
</head>
<body>
    <h1>Student form</h1>
    <form method="POST">
        <input name="name" type="text" placeholder="enter name "> <br>
        <input name="email" type="email" placeholder="enter email "> <br>
        <input name="dept" type="text" placeholder="enter dept "> <br>
        <input name="sub" type="submit" value="submit"> <br>
    </form>

    <!--fetch data php-->
        <table border="1"> 
            <thead>
                <th>Id</th>
                <th>name</th>
                <th>email</th>
                <th>Dept</th>
                <th>EDIT</th>
                <th>DELETE</th>

            </thead>
            <tbody>
              <?php
                  $select = "SELECT * FROM student";
                  $exc = mysqli_query($connect,$select);
                  
                  while($row = mysqli_fetch_assoc($exc)){?>
                     <tr>
                       <td><?php echo $row['id'] ?></td>
                        <td><?php echo $row['name'] ?></td>
                        <td><?php echo $row['email'] ?></td>
                        <td><?php echo $row['dept'] ?></td>
                        <td><a href="edit.php?idno=<?php  echo $row['id'] ?>">Edit</a></td>
                        <td><a href="delete.php?idno=<?php  echo $row['id'] ?>">DELETE</a></td>

                     </tr>



                <?php  }


               ?>
            </tbody>
        </table>
    <!--fetch data php ends here -->
</body>
</html>