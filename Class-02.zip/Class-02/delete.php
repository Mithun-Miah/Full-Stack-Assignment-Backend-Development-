<?php
include 'db.php';
   $id = $_GET['idno'];
   
   $delete = "DELETE FROM student WHERE id=$id";
   $ex = mysqli_query($connect,$delete);
   if($ex){
     header("location:index.php");
   }

?>