<?php
include 'db.php';
  $id = $_GET['idno'];
  echo $id;

  $select = "SELECT * FROM student";
  $ex = mysqli_query($connect,$select);
  $row = mysqli_fetch_array($ex);


  if(isset($_POST['sub'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $dept = $_POST['dept'];
    $update = "UPDATE student 
    set name='$name',email='$email' , dept='$dept' WHERE id= $id";
    $upEx = mysqli_query($connect,$update);


  }


?>
<h1>Edit page</h1>
<form method="POST">
        <input name="name" value="<?php echo $row['name'] ?>"  type="text" placeholder="enter name "> <br>
        <input name="email"value="<?php echo $row['email'] ?>" type="email" placeholder="enter email "> <br>
        <input name="dept"value="<?php echo $row['dept'] ?>" type="text" placeholder="enter dept "> <br>
        <input name="sub" type="submit" value="update"> <br>
    </form>