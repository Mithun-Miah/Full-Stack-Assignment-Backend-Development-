<?php
$connect = mysqli_connect("localhost","root","","myclass");
// if($connect){
//     echo "<script>alert('database connect success')</script>";
// }else{
//     echo "<script>alert('database connect failed')</script>";
// }

?>