<?php
include('db.php');
?>

<?php
if(isset($_POST['submit_btn']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subjectText = $_POST['subjectText'];
    $msg = $_POST['msg'];

    $insert = "INSERT INTO user_leave(name,email,subject,msg) VALUES('$name','$email','$subjectText','$msg')";

    $run = mysqli_query($connect,$insert);

    if($run){
        echo "<script>alert('Sent Success')</script>";
    }else{
        echo "<script>alert('Sent Failed')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application</title>
    <link rel="stylesheet" href="bs/css/bootstrap.min.css">
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12"></div>

            <div class="col-lg-6 col-md-6 col-sm-12">
                <h3 class="text-center py-2 bg-secondary text-light">Leave Application</h3>

                <form action="" method="post">
                    <div class="form-group mb-3">
                        <input type="text" name="name" class="form-control" placeholder="Enter Name" required>
                    </div>
                    <div class="form-group mb-3">
                        <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                    </div>
                    <div class="form-group mb-3">
                        <input type="text" name="subjectText" class="form-control" placeholder="Enter Subject" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Message</label>
                        <textarea name="msg" id="" class="form-control" rows="5"></textarea>
                    </div>
                    <div class="form-group mb-3">
                        <input type="submit" name="submit_btn" class="form-control btn btn-primary">
                    </div>
                </form>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-12"></div>
        </div>
    </div>

    <div class="container">
		<div class="row">
			<div class="col-lg-1"></div>
				
			<div class="col-lg-10">

                <h3 class="text-center py-2 bg-success">Application Status</h3>
				<hr>
			
				<div class="text-center">
					<table class="table table-striped border">
						<thead class="table-dark fw-bold">
							<tr>
								<td>#</td>
								<td>Name</td>
								<td>Email</td>
								<td>Subject</td>
								<td>Message</td>
								<td>Status</td>
							</tr>
						</thead>
						
						<tbody>
						<?php
							$select = "SELECT * FROM user_leave";
							$data = mysqli_query($connect, $select);
							while($row = mysqli_fetch_array($data)){
						?>
							<tr>
								<td><?php echo $row['id'];?></td>
								<td><?php echo $row['name'];?></td>
								<td><?php echo $row['email'];?></td>
								<td><?php echo $row['subject'];?></td>
								<td><?php echo $row['msg'];?></td>
								<td>
									<?php
										if($row['status']==1)
										{
											echo '<a href="active.php?id='.$row['id'].'&status=0" class="btn btn-success disabled">Approved</a>';
										}else
										{
											echo '<a href="active.php?id='.$row['id'].'&status=1" class="btn btn-danger disabled">Rejected</a>';
										}

										if($row['status2']==1)
										{
											echo '<a href="pending.php?id='.$row['id'].'&status2=0" class="btn btn-primary disabled">Hold</a>';
										}else
										{
											echo '<a href="pending.php?id='.$row['id'].'&status2=1" class="btn btn-warning disabled">Pending</a>';
										}
									?>
								</td>
							</tr>
							<?php
							}
							?>
						</tbody>
					</table>
				</div>
			</div>

            <div class="col-lg-1"></div>
		</div>
	</div>
    
</body>
</html>