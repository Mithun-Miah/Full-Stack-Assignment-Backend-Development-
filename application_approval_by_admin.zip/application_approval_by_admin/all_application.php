<?php
include('db.php');
//session_start();
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Applications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="text-center">
					<h3>All Users Application Recorde</h3>
					<hr>
				</div>
			</div>
				
			<div class="col-lg-9">
			
				<div class="text-center">
					<table class="table table-striped border">
						<thead class="table-dark fw-bold">
							<tr>
								<td>#</td>
								<td>Name</td>
								<td>Email</td>
								<td>Subject</td>
								<td>Message</td>
								<td>Status</td>
							</tr>
						</thead>
						
						<tbody>
						<?php
							$select = "SELECT * FROM user_leave";
							$data = mysqli_query($connect, $select);
							while($row = mysqli_fetch_array($data)){
						?>
							<tr>
								<td><?php echo $row['id'];?></td>
								<td><?php echo $row['name'];?></td>
								<td><?php echo $row['email'];?></td>
								<td><?php echo $row['subject'];?></td>
								<td><?php echo $row['msg'];?></td>
								<td>
										<?php
											if($row['status']==1)
											{
												echo '<a href="active.php?id='.$row['id'].'&status=0" class="btn btn-success">Approved</a>';
											}else
											{
												echo '<a href="active.php?id='.$row['id'].'&status=1" class="btn btn-danger">Rejected</a>';
											}

											if($row['status2']==1)
											{
												echo '<a href="pending.php?id='.$row['id'].'&status2=0" class="btn btn-primary">Hold</a>';
											}else
											{
												echo '<a href="pending.php?id='.$row['id'].'&status2=1" class="btn btn-warning">Pending</a>';
											}
										?>
								</td>
							</tr>
							<?php
							}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
  
	
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>