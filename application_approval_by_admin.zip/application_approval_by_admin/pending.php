<?php
include('db.php');
?>

<?php
$id = $_GET['id'];
$status = $_GET['status2'];

$update = "UPDATE user_leave SET status2=$status WHERE id=$id";

$ex = mysqli_query($connect, $update);

header('location:all_application.php');
?>