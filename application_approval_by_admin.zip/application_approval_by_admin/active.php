<?php
include('db.php');
?>

<?php
$id = $_GET['id'];
$status = $_GET['status'];

$update = "UPDATE user_leave SET status=$status WHERE id=$id";

$ex = mysqli_query($connect, $update);

header('location:all_application.php');
?>