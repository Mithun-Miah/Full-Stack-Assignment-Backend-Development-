<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mithun Developer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
        <div class="page-header">
        <h1>Student Form <small>by simpleawesome</small></h1>
    </div>
    </div>
    <div class="container">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Form</h3>
            </div>
        <div class="panel-body">
        <form class="form-horizontal">
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">ID</label> <button type="submit" class="btn btn-primary" id="btn-search">Search</button>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="id">
            </div>
          </div>
          <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Name</label> 
            <div class="col-sm-4">
              <input type="text" class="form-control" id="name">
            </div>
          </div>
          <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Sex</label>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="sex">
            </div>
          </div>
          <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Phone</label>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="phone">
            </div>
          </div>
           <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Address</label>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="address">
            </div>
          </div>
        </form>
    </div>
</div>
</div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
	<script src="process.js"></script>
</body>
</html>