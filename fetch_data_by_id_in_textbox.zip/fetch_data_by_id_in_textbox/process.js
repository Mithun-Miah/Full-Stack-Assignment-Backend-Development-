function search(){
  $("#loading").show(); // Show  the loading
  
  $.ajax({
        type: "POST", // The method of sending data can be with GET or POST
        url: "search.php", // Fill in url / php file path to destination
        data: {id : $("#id").val()}, // data to be sent to the process file
        dataType: "json",
        beforeSend: function(e) {
            if(e && e.overrideMimeType) {
                e.overrideMimeType("application/json;charset=UTF-8");
            }
    },
    success: function(response){ // When the submission process is successful
            $("#loading").hide(); // Hide loading
            
            if(response.status == "success"){ // If the content of the status array is success
        $("#name").val(response.name); // set textbox with id name
        $("#sex").val(response.sex); // set textbox with id sex
        $("#phone").val(response.phone); // set textbox with id phone
        $("#address").val(response.address); // set textbox with id address
      }else{ // If the contents of the status array are failed
        alert("undefined");
      }
    },
        error: function (xhr, ajaxOptions, thrownError) { // When there is an error
      alert(xhr.responseText);
        }
    });
}
$(document).ready(function(){
  $("#loading").hide(); // Hide loading
  
    $("#btn-search").click(function(){ // When the user clicks the Search button
        search(); // Call search function 
    });
  
    $("#id").keyup(function(){ // When the user presses a key on the keyboard
    if(event.keyCode == 13){ // If user press ENTER key
      search(); // Call  search function 
    }
  });
});