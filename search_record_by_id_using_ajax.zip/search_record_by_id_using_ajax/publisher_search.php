<?php
$connect = mysqli_connect("localhost","root","","book_entry_soft");

$id = $_POST['id']; // Retrieve id data sent via AJAX
$query = mysqli_query($connect, "SELECT * FROM publisher WHERE publisher_id='$id'"); // Show student data with the id
$row = mysqli_num_rows($query); // Calculate how much data from the $query execution results
if($row > 0){ // If the data is more than 0
  $data = mysqli_fetch_array($query); // take the student's data
  
  // BUat sebuah array
  $callback = array(
    'status' => 'success', // Set array status with success
    'pub_name' => $data['publisher_name'], // Set array name with the contents of the name field in the student table
  );
}else{
  $callback = array('status' => 'failed'); // set the status array with failed
}
echo json_encode($callback); // converting varibel $callback to JSON
?>