<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  
	<div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			
			<div class="col-lg-6">
				<h1 class="text-center py-3 bg-primary text-light">Welcome To Home</h1>
				
				<div class="text-center mb-4">
					<a href="register.php" class="btn btn-info">Register Here</a>
				</div>
				<div class="text-center">
					<a href="login.php" class="btn btn-info">Login Here</a>
				</div>
				
			</div>
			
			<div class="col-lg-3"></div>
		</div>
	</div>
  
	
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>