<?php 

  //when you start work on login. Firstly start session.
  session_start();

  //include connection file here
  include('db.php');

  //here i am checking. User logged in or not.
  if(!empty($_SESSION['login_id']))
  {
      header("location:welcome.php");
  }

  $error = '';  //Initialize error variable

  if(isset($_POST['submit_btn'])) 
  {

      $email = $_POST['email'];
      $pass = $_POST['pass']; 

      //check query for user and password exist in user table or not
      $sql = "SELECT * FROM user WHERE email = '$email' and password = '$pass'";

      $row = mysqli_query($connect,$sql);
      $count = mysqli_num_rows($row);

      if($count > 0)
      {

          //Here I am fetching user detail
          $rows = mysqli_fetch_object($row);

          // Here I am checking user login enable or disable.. if user status is 1. So it will redirect to welcome page otherwise show error message.
          if($rows->status == '1')
          {
              $_SESSION['login_id'] = $rows->id;
              $_SESSION['login_name'] = $rows->name;
              $_SESSION['login_email'] = $rows->email;
              header("location: welcome.php");
          }
          else
          {
              $error = "You don't have permission to login";
          }
          
      }
      else 
      {
          $error = "Your Login email or Password is invalid";
      }
      
   }

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  
	<div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			
			<div class="col-lg-6">
				<h1 class="text-center py-3 bg-primary text-light">Login</h1>

				<div class="text-center text-danger fw-bold my-2"><?php echo $error; ?></div>
				
				<form method="post" id="login-form" class="form">
					
					<input type="email" name="email" class="form-control mb-3" placeholder="Enter Email">
					
					<input type="text" name="pass" class="form-control mb-3" placeholder="Enter Password">
					
					<input type="submit" name="submit_btn" class="form-control mb-3 btn btn-success">
				</form>
				
				<div class="text-center">
					<a href="register.php" class="btn btn-info">Register Here</a>
				</div>
				
			</div>
			
			<div class="col-lg-3"></div>
		</div>
	</div>
  
	
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>