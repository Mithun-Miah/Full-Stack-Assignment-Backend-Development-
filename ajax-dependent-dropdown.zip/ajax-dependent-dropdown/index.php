<?php
include "db.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Ajax Dependent Dropdown</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            Category Subcategory Dropdown in PHP MySQL Ajax
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="form-group">
                                    <label for="CATEGORY-DROPDOWN">Category</label>
                                    <select class="form-select" id="category-dropdown">
                                        <option value="">Select Category</option>
                                        <?php
                                        $result = mysqli_query($conn, "SELECT * FROM category where id");
                                        while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                            <option value="<?php echo $row['id']; ?>"><?php echo $row["category_name"]; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="SUBCATEGORY">Sub Category</label>
                                    <select class="form-control" id="sub-category-dropdown">
                                        <option value="">Select Sub Category</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="ajax-test.js"></script>
    </body>
</html>