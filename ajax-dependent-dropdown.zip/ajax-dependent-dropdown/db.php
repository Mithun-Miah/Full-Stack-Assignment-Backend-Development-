<?php
$serverName = "localhost";
$username = "root";
$password = "";
$dbname = "book_entry_soft";

$conn = mysqli_connect($serverName,$username,$password,$dbname);

if ($conn)
{
    //echo "Connection Ok";
}else
{
    echo "Connection Failed".mysqli_connect_error();
}
?>