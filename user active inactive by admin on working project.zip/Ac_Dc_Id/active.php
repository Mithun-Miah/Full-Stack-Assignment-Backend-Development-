<?php
include('db.php');
?>

<?php
$id = $_GET['id'];
$status = $_GET['status'];

$update = "UPDATE user SET status=$status WHERE id=$id";
$ex = mysqli_query($connect, $update);

header('location:userAll.php');
?>