<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "act_dec";

$connect = mysqli_connect($serverName,$userName,$password,$dbName);

if($connect)
{
	//echo "Connection Success";
}else
{
	echo "Connection Failed";
}
?>