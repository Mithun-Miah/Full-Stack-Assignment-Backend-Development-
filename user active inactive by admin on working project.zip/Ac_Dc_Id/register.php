<?php
include('db.php');
?>

<?php
if(isset($_POST['submit_btn']))
{
	$name = $_POST['name'];
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	
	$insert = "INSERT INTO user(name,email,password) VALUES('$name','$email','$pass')";
	$ex = mysqli_query($connect, $insert);
	
	if($ex)
	{
		echo "<script>alert('Data Inserted')</script>";
	}else
	{
		echo "<script>alert('Data Not Inserted')</script>";
	}
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  
	<div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			
			<div class="col-lg-6">
				<h1 class="text-center py-3 bg-primary text-light">Register</h1>
				
				<form method="post">
					<input type="text" name="name" class="form-control mb-3" placeholder="Enter Name" required>
					
					<input type="email" name="email" class="form-control mb-3" placeholder="Enter Email" required>
					
					<input type="text" name="pass" class="form-control mb-3" placeholder="Enter Password" required>
					
					<input type="submit" name="submit_btn" class="form-control mb-3 btn btn-primary">
				</form>
				
				<div class="text-center">
					<a href="index.php" class="btn btn-info">Login</a>
				</div>
			</div>
			
			<div class="col-lg-3"></div>
		</div>
	</div>
  
	
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>