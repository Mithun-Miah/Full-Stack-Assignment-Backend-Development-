<?php
include('db.php');
session_start();
?>

<?php
if(isset($_POST['submit_btn']))
{
	$useremail = mysqli_real_escape_string($connect,$_POST['email']);
    $userpass = mysqli_real_escape_string($connect,$_POST['pass']);
	
	$select = "SELECT id FROM user WHERE email = '$useremail' and password = '$userpass'";
	$ex = mysqli_query($connect, $select);
	$row = mysqli_fetch_array($ex);
	
	//$active = $row['status'];
    //$count = mysqli_num_rows($ex);

	/*if($active == 1)
	{
		if($row>0) {
         //session_register("name");
         $_SESSION['name'] = $username;
         $_SESSION['email'] = $useremail;
         
         header("location: welcome.php");
		}	
	}else {
         $error = "Your Login Name or Password is invalid";
    }*/
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($row>0) {
         //session_register("name");
         $_SESSION['name'] = $username;
         $_SESSION['email'] = $useremail;
         
         header("location: welcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  
	<div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			
			<div class="col-lg-6">
				<h1 class="text-center py-3 bg-primary text-light">Login</h1>
				
				<form method="post">
					
					<input type="email" name="email" class="form-control mb-3" placeholder="Enter Email">
					
					<input type="text" name="pass" class="form-control mb-3" placeholder="Enter Password">
					
					<input type="submit" name="submit_btn" class="form-control mb-3 btn btn-success">
				</form>
				
				<div class="text-center">
					<a href="register.php" class="btn btn-info">Register Here</a>
				</div>
				
			</div>
			
			<div class="col-lg-3"></div>
		</div>
	</div>
  
	
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>