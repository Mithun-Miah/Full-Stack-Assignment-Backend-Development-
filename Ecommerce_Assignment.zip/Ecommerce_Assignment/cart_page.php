<?php
	include_once 'db_connect.php';

    if(isset($_POST['add_btn'])){
        $quantity = $_POST['quantity'];
        $updt_id = $_POST['updt_id'];

        $update = "update user_order set quantity = '$quantity' where id='$updt_id'";
        $up_query = mysqli_query($connect, $update);
    }

    if(isset($_GET['remove_id'])){
        $id = $_GET['remove_id'];
        $delete = "DELETE FROM user_order WHERE id = '$id'";
        $rem_query = mysqli_query($connect, $delete);
        header("location:cart_page.php");
    }

    if(isset($_GET['DeleteALL'])){
        $delete = "DELETE FROM user_order";
        $ex = mysqli_query($connect,$delete);
        header("location:cart_page.php");
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order List</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body>

        <?php
          include 'navbar.php';
        ?>

        <div class="container mb-5">
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-12"></div>
                
                <div class="col-lg-10 col-md-10 col-sm-12">
                    <h3 class="text-center">Order List</h3>
                    <hr>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Product Name</th>
                                <th>Product Image</th>
                                <th>Product Price</th>
                                <th>Quantity</th>
                                <th>Grand Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                                $select = "SELECT * FROM user_order";
                                $query = mysqli_query($connect, $select);
                                while($row = mysqli_fetch_array($query)){ ?>

                            <tr>
                                <td><?php echo $row['id'] ?></td>
                                <td><?php echo $row['p_name'] ?></td>
                                <td><img src="admin/product_image/<?php echo $row['p_image'] ?>" width="100"
                                        alt="image">
                                </td>
                                <td><?php echo $row['p_price'] ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="number" name="quantity" max="5" min="1"
                                            value="<?php echo $row['quantity'] ?>">
                                        <input type="hidden" name="updt_id" value="<?php echo $row['id'] ?>">
                                        <button class="btn btn-outline-success" name="add_btn">Add</button>
                                    </form>
                                </td>
                                <td>
                                    <?php echo $g_total = ($row['p_price'] * $row['quantity']) ?>
                                </td>
                                <td>
                                    <a href="cart_page.php?remove_id=<?php echo $row['id'] ?>"
                                        onclick="return confirm('are you sure?')">Remove</a>
                                </td>
                            </tr>

                            <?php
                            $total +=  $g_total;
                            }
                            ?>

                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><b>Total</b></td>
                                <td><b><?php echo $total ?></b></td>
                                <td>
                                    <a href="cart_page.php?DeleteALL="
                                        onclick="return confirm('click ok to confirm?')">Delete All</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="text-end">

                    <?php if(isset($_SESSION['u_email'])){ ?>
                        <a href="order_page.php" class="btn btn-primary">Place Order</a>
                    <?php }else{ ?>
                        <!-- <a href="cart_page.php" class="btn btn-primary">Place Order</a> -->
                        <!-- <a href="login_modal.php" type="button" data-bs-toggle="modal" data-bs-target="#userLoginByCart" class="btn btn-primary">Place Order</a> -->

                        <div>
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Login Now
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                <!-- Log in start -->
                                <?php

                                    if(isset($_POST['u_login_btn'])){

                                    $u_email = mysqli_real_escape_string($connect, $_POST['u_email']);
                                    $u_pass = mysqli_real_escape_string($connect, $_POST['u_pass']);
                                    //$u_pass = $_POST['u_pass'];
                                    $query =   mysqli_query($connect,"SELECT * FROM user_reg WHERE u_email='$u_email' AND u_pass='$u_pass'");

                                    $row = mysqli_fetch_array($query);

                                    if($row){
                                        $_SESSION['u_email'] = $row['u_email'];
                                        //header("location:user_panel.php");
                                        echo "<script>window.location.href = 'user_panel.php'</script>";
                                    }else{
                                        echo "<script>alert('Email and Password Not match')</script>";
                                        //header("location:index.php");
                                    }

                                    }
                                ?>
                                    <div class="user_login_box">
                                        <form method="post">
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Email address</label>
                                                <input type="email" name="u_email" class="form-control" id="exampleInputEmail1">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="exampleInputPassword1" class="form-label">Password</label>
                                                    <input type="password" name="u_pass" class="form-control" id="exampleInputPassword1">
                                                </div>

                                                <button type="submit" class="btn btn-primary form-control" name="u_login_btn">Log In</button>
                                                </form>
                                            </div>
                                            <!-- Log in end -->
                                    <p class="mt-2"><span>If you don't have account, please <a href="user_signup.php">Signup Now</a></span></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        
                    <?php } ?>
                    
                    </div>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-12"></div>
            </div>
        </div>

        <br><br><br>


        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>