<?php
	include_once 'db_connect.php';

    session_start();

    if($_SESSION['u_email']==true){
        echo "welcome ". $_SESSION['u_email'];
        //$email = $_SESSION['u_email'];
    }else{
        header('Location: index.php');
    }

    if(isset($_POST['add_btn'])){
        $quantity = $_POST['quantity'];
        $updt_id = $_POST['updt_id'];

        $update = "update user_order set quantity = '$quantity' where id='$updt_id'";
        $up_query = mysqli_query($connect, $update);
    }

    if(isset($_GET['remove_id'])){
        $id = $_GET['remove_id'];
        $delete = "DELETE FROM user_order WHERE id = '$id'";
        $rem_query = mysqli_query($connect, $delete);
        header("location:cart_page.php");
    }

    if(isset($_GET['DeleteALL'])){
        $delete = "DELETE FROM user_order";
        $ex = mysqli_query($connect,$delete);
        header("location:cart_page.php");
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order List</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body>

        <?php
          include 'navbar.php';
        ?>

        <div class="container mb-5">
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-12"></div>
                <div class="col-lg-10 col-md-10 col-sm-12">
                    <h3 class="text-center">Order List</h3>
                    <hr>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Product Name</th>
                                <th>Product Image</th>
                                <th>Product Price</th>
                                <th>Quantity</th>
                                <th>Grand Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                                $select = "SELECT * FROM user_order";
                                $query = mysqli_query($connect, $select);
                                while($row = mysqli_fetch_array($query)){ ?>

                            <tr>
                                <td><?php echo $row['id'] ?></td>
                                <td><?php echo $row['p_name'] ?></td>
                                <td><img src="admin/product_image/<?php echo $row['p_image'] ?>" width="100"
                                        alt="image">
                                </td>
                                <td><?php echo $row['p_price'] ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="number" name="quantity" max="5" min="1"
                                            value="<?php echo $row['quantity'] ?>">
                                        <input type="hidden" name="updt_id" value="<?php echo $row['id'] ?>">
                                        <button class="btn btn-outline-success" name="add_btn">Add</button>
                                    </form>
                                </td>
                                <td>
                                    <?php echo $g_total = ($row['p_price'] * $row['quantity']) ?>
                                    <?php //echo $g_total = ((int)$row['p_price'] * (int)$row['quantity']) ?>
                                </td>
                                <td>
                                    <a href="cart_page.php?remove_id=<?php echo $row['id'] ?>"
                                        onclick="return confirm('are you sure?')">Remove</a>
                                </td>
                            </tr>

                            <?php
                            $total +=  $g_total;
                            }
                            ?>

                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><b>Total</b></td>
                                <td><b><?php echo $total ?></b></td>
                                <td>
                                    <a href="cart_page.php?DeleteALL="
                                        onclick="return confirm('click ok to confirm?')">Delete All</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="text-end">
                        <a href="order_page.php" class="btn btn-primary">Place Order</a>
                    </div>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-12"></div>
            </div>
        </div>


        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>