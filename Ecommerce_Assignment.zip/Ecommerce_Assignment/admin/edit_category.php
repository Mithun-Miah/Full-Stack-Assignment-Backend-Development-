<?php
//session_start();

include_once 'db_connect.php';

$id = $_GET['idNo'];

//For Show Data in Edit page input field
$read = "SELECT * FROM category WHERE id=$id";
$query = mysqli_query($connect, $read);
$row = mysqli_fetch_array($query);

if(isset($_POST['cat_update_btn'])){
    $cat_name = $_POST['cat_name'];

    if($cat_name == ""){
        echo "<script>alert('Fields Are Required...')</script>";
    }else{
        $update = "UPDATE category SET cat_name = '$cat_name' where id = $id ";
        $query = mysqli_query($connect, $update);
        if($query){
            echo "<script>alert('Category Update Success')</script>";
        } else{
            echo "<script>alert('Category Update Fail')</script>";
        }
    }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Category</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="admin_dashboard.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />

    </head>
    <body>
        <?php include_once "nav_menu.php"; ?>

        <!-- Edit Product Start -->
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h4 class="text-center">Edit Category</h4>
                    <hr>

                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="text-center">
                            <button class="btn btn-primary mb-3" name="cat_update_btn">Edit</button>
                            <a href="add_category.php" class="btn btn-info mb-3">Go Back</a>
                        </div>

                        <div class="mb-2">
                            <label for="pt" class="form-label">Category Name</label>
                            <input type="text" name="cat_name" value="<?php echo $row['cat_name']; ?>"
                            class="form-control">
                        </div>

                    </form>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>
        <!-- Edit Product End -->


        <script>

        //After refresh/reload Data Resubmission Stop with this code
        if (window.history.replaceState) {
            window.history.replaceState(null, null, location.href)
        }
        </script>

        <!-- <script src="bootstrap/js/bootstrap.bundle.min.js"></script> -->
        <script src="admin_dashboard.js"></script>
    </body>
</html>