<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--<title>Add Product</title>-->
        <!--<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">-->
        <!--<link rel="stylesheet" href="admin_dashboard.css">-->
        <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />-->
    </head>
    <body>

			<!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">

                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Entry
                                        Menu</a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="add_product.php">Add Product</a>
                                        <a class="dropdown-item" href="#!">Author Entry</a>
                                        <a class="dropdown-item" href="#!">Publisher Entry</a>
                                        <a class="dropdown-item" href="#!">Category Entry</a>
                                        <a class="dropdown-item" href="#!">Sub-Category Entry</a>
                                    </div>
                                </li>
                                <li class="nav-item active"><a class="nav-link" href="admin_dashboard.php">Home</a>
                                </li>
                                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>



        <!--<script src="bootstrap/js/bootstrap.bundle.min.js"></script>-->
        <!--<script src="admin_dashboard.js"></script>-->
    </body>
</html>