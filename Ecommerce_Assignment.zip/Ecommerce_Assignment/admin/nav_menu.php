<!-- Top navigation-->
<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <div class="container-fluid">

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Entry
                        Menu</a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="add_product.php">Add Product</a>
                        <a class="dropdown-item" href="add_carousel.php">Add Carousel</a>
                        <a class="dropdown-item" href="add_flash_sale.php">Add Flash Sale</a>
                        <a class="dropdown-item" href="add_category.php">Category Add</a>
                    </div>
                </li>
                <li class="nav-item active"><a class="nav-link" href="admin_dashboard.php">Home</a>
                </li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>