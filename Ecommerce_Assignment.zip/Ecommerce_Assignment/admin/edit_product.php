<?php
//session_start();

include_once 'db_connect.php';

$id = $_GET['idNo'];

//For Show Data in Edit page input field
$read = "SELECT * FROM product_add WHERE id=$id";
$query = mysqli_query($connect, $read);
$row = mysqli_fetch_array($query);

if(isset($_POST['product_update_btn'])){
    $p_name = $_POST['p_name'];
    $p_qty = $_POST['p_qty'];
    $p_price = $_POST['p_price'];
    $total_price = $_POST['total_price'];

    $image_name = $_FILES['p_image']['name'];
    $tmp_name = $_FILES['p_image']['tmp_name'];
    
    $upload = move_uploaded_file($tmp_name, "product_image/".$image_name);

    if($upload){
        $update = "UPDATE product_add SET p_name = '$p_name', p_qty = '$p_qty', p_price='$p_price', total_price='$total_price' where id = $id ";
        $query = mysqli_query($connect, $update);
        if($query){
            echo "<script>alert('Data Update Success')</script>";
        } else{
            echo "<script>alert('Data Update Fail')</script>";
        }
    }else{
        echo "<script>alert('Update Failed !')</script>";
    }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Add Product</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="admin_dashboard.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
		
    </head>
    <body>
        <?php include_once "nav_menu.php"; ?>
		
		<!-- Edit Product Start -->
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-12"></div>
				
				<div class="col-lg-6 col-md-6 col-sm-12">
					<h4 class="text-center">Edit Product</h4>
                    <hr>
			   
					<form action="" method="post" enctype="multipart/form-data">
                        <div class="text-center">
                            <button class="btn btn-primary mb-3" name="product_update_btn">Edit Product</button>
                            <a href="add_product.php" class="btn btn-info mb-3">Go Back</a>
                        </div>

                        <div class="mb-2">
                            <label for="pt" class="form-label">Product Title</label>
                            <input type="text" name="p_name" id="pt" value="<?php echo $row['p_name']; ?>" placeholder="Product Title" class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="pq" class="form-label">Product Quantity</label>
                            <input type="number" name="p_qty" id="pq" value="<?php echo $row['p_qty']; ?>" class="form-control" onkeyup="multi(this.value)">
                        </div>
                        <div class="mb-2">
                            <label for="pc" class="form-label">Product Price</label>
                            <input type="text" name="p_price" id="pc" value="<?php echo $row['p_price']; ?>" class="form-control" onkeyup="multi(this.value)">
                        </div>
                        <div class="mb-2">
                            <label for="tp" class="form-label">Total Price</label>
                            <input type="number" name="total_price" id="total_price" value="<?php echo $row['total_price']; ?>" class="form-control" value="readonly" aria-label="readonly input example" readonly>
                        </div>
						
						<?php
						 if($row['p_image'] == ''){
							echo '<img src="images/default_user_icon.png" width="80">';
						 }else{
							echo '<img src="product_image/'.$row['p_image'].'" width="80">';
						 }

					  ?>

                        <!-- <p> <img src="product_image/<?php //echo $row['p_image'] ?>" height="60" width="60" alt=""> </p> -->
				  
						<div class="mb-2">
                            <label for="tp" class="form-label">Product Image</label>
                            <input type="file" name="p_image" class="form-control" value="<?php echo $row['p_image'] ?>">
                        </div>

                    </form>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12"></div>
			</div>
		</div>
		<!-- Edit Product End -->


		<script>
		// auto addition input fields value start
		function multi(value){
			var a = document.getElementById('pq').value; 
			var b = document.getElementById('pc').value;

			var multy = parseFloat(a) * parseFloat(b);
			document.getElementById('total_price').value = parseFloat(multy).toFixed(2);
		}
		// auto addition input fields value end

        //After refresh/reload Data Resubmission Stop with this code
        if (window.history.replaceState) {
            window.history.replaceState(null, null, location.href)
        }
        </script>

        <!-- <script src="bootstrap/js/bootstrap.bundle.min.js"></script> -->
        <script src="admin_dashboard.js"></script>
    </body>
</html>