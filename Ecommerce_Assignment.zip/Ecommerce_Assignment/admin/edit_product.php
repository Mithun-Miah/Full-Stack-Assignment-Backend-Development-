<?php
session_start();

include_once 'db_connect.php';

if(!isset($_SESSION['email'])){
	header("location:index.php");
}

// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h4 class='text-center text-light bg-success py-3'>Email : $_SESSION[email]</h4>");
    //echo("<h1>Password : $_SESSION[password]</h1>");
} else{
    header('Location: index.php');
}

//$id = $_SESSION['id'];

if(isset($_POST['product_update_btn'])){

    $p_name = $_POST['p_name'];
    $p_qty = $_POST['p_qty'];
    $p_price = $_POST['p_price'];
    $total_price = $_POST['total_price'];
	
	$update = "UPDATE `product_add` SET p_name = '$p_name', p_qty = '$p_qty', p_price = '$p_price', total_price = '$total_price', p_qty = '$p_qty' WHERE id = '$id'";
	$up_query = mysqli_query($connect, $update);

   //mysqli_query($connect, "UPDATE `product_add` SET p_name = '$p_name', p_qty = '$p_qty', p_price = '$p_price', total_price = '$total_price', p_qty = '$p_qty' WHERE id = '$id'") or die('query failed **-**');
   
    $image = $_FILES['p_image']['name'];
    $image_size = $_FILES['p_image']['size'];
    $image_tmp_name = $_FILES['p_image']['tmp_name'];
    $image_folder = 'product_image/'.$image;

   if(!empty($image)){
      if($image_size > 2000000){
         echo "<script>alert('Image Size Too Big...')</script>";
      }else{
         $image_update_query = mysqli_query($connect, "UPDATE `product_add` SET p_image = '$p_image' WHERE id = '$id'") or die('query failed****');
         if($image_update_query){
         move_uploaded_file($image_tmp_name, $image_folder);
         }
		 echo "<script>alert('image updated succssfully...')</script>";
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Add Product</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="admin_dashboard.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
		
    </head>
    <body>
        <?php include_once "nav_menu.php"; ?>
		
		<!-- Edit Product Start -->
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-12"></div>
				
				<div class="col-lg-6 col-md-6 col-sm-12">
					<h4><?php //echo $message; ?></h4>
					<h4 class="text-center">Edit Product</h4>
                    <hr>
					
					<?php
					  $select = mysqli_query($connect, "SELECT * FROM `product_add` WHERE id = '$id'") or die('query failed----');
					  if(mysqli_num_rows($select) > 0){
						 $fetch = mysqli_fetch_array($select);
					  }
				   ?>
			   
					<form action="" method="post" enctype="multipart/form-data">
                        <div class="text-center">
                            <button class="btn btn-primary mb-3" name="product_update_btn">Edit Product</button>
                            <a href="add_product.php" class="btn btn-info mb-3">Go Back</a>
                        </div>

                        <div class="mb-2">
                            <label for="pt" class="form-label">Product Title</label>
                            <input type="text" name="p_name" id="pt" value="<?php echo $fetch['p_name']; ?>" placeholder="Product Title" class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="pq" class="form-label">Product Quantity</label>
                            <input type="number" name="p_qty" id="pq" value="<?php echo $fetch['p_qty']; ?>" class="form-control" onkeyup="multi(this.value)">
                        </div>
                        <div class="mb-2">
                            <label for="pc" class="form-label">Product Price</label>
                            <input type="text" name="p_price" id="pc" value="<?php echo $fetch['p_price']; ?>" class="form-control" onkeyup="multi(this.value)">
                        </div>
                        <div class="mb-2">
                            <label for="tp" class="form-label">Total Price</label>
                            <input type="number" name="total_price" id="total_price" value="<?php echo $fetch['total_price']; ?>" class="form-control" value="readonly" aria-label="readonly input example" readonly>
                        </div>
						
						<?php
						 if($fetch['p_image'] == ''){
							echo '<img src="images/default_user_icon.png" width="80">';
						 }else{
							echo '<img src="product_image/'.$fetch['p_image'].'" width="80">';
						 }

					  ?>
				  
						<div class="mb-2">
                            <label for="tp" class="form-label">Product Image</label>
                            <input type="file" name="p_image" class="form-control" >
                        </div>

                    </form>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12"></div>
			</div>
		</div>
		<!-- Edit Product End -->


		<script>
		// auto addition input fields value start
		function multi(value){
			var a = document.getElementById('pq').value; 
			var b = document.getElementById('pc').value;

			var multy = parseFloat(a) * parseFloat(b);
			document.getElementById('total_price').value = parseFloat(multy).toFixed(2);
		}
		// auto addition input fields value end

        //After refresh/reload Data Resubmission Stop with this code
        if (window.history.replaceState) {
            window.history.replaceState(null, null, location.href)
        }
        </script>

        <!-- <script src="bootstrap/js/bootstrap.bundle.min.js"></script> -->
        <script src="admin_dashboard.js"></script>
    </body>
</html>