<?php
// For Store data
session_start();

$message = "";

if(!isset($_SESSION['email'])){
	header("location:index.php");
}

// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h4 class='text-center text-light bg-success py-3'>Email : $_SESSION[email]</h4>");
    //echo("<h1>Password : $_SESSION[password]</h1>");
} else{
    header('Location: index.php');
}

include_once "db_connect.php";

if(isset($_POST['add_btn'])){
    $p_name = $_POST['p_name'];
    $p_qty = $_POST['p_qty'];
    $p_price = $_POST['p_price'];
    $total_price = $_POST['total_price'];
    $p_desc = $_POST['p_desc'];
	
	$image = $_FILES['p_image']['name'];
    $image_size = $_FILES['p_image']['size'];
    $image_tmp_name = $_FILES['p_image']['tmp_name'];
    $image_folder = 'product_image/'.$image;

    if($p_name == "" || $p_qty == "" || $p_price == "" || $total_price == "" || $p_desc == ""){
        echo "<script>alert('Fields Are Required...')</script>";
    }else{
        if($image_size > 2000000){
			echo "<script>alert('Image Size Too Big...')</script>";
		}else{
			$insert = "INSERT INTO product_add(p_name,p_qty,p_price,total_price,p_image,p_desc)
        VALUES('$p_name', '$p_qty', '$p_price', '$total_price','$image','$p_desc')";

        $insert_query = mysqli_query($connect, $insert);

        if($insert_query){
			move_uploaded_file($image_tmp_name, $image_folder);
            //echo "<script>alert('Product Add Success...')</script>";
			$message = 'Product Add Success';
			header('location:add_product.php');
        }else{
            echo "<script>alert('Product Add Failed...')</script>";
        }
		}
    }
}


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Add Product</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="admin_dashboard.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
		
		<!-- data table cdn -->
		<link rel="stylesheet" href="../data_tables_cdn_files/bootstrap.min.css">
        <link rel="stylesheet" href="../data_tables_cdn_files/dataTables.bootstrap5.min.css">

        <script src="../data_tables_cdn_files/jquery-3.6.0.min.js"></script>
        <script src="../data_tables_cdn_files/bootstrap.bundle.min.js"></script>
        <script src="../data_tables_cdn_files/jquery.dataTables.min.js"></script>
        <script src="../data_tables_cdn_files/dataTables.bootstrap5.min.js"></script>
    </head>
    <body>
        <?php include_once "nav_menu.php"; ?>
		
		<!-- Add Product Start -->
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-12"></div>
				
				<div class="col-lg-6 col-md-6 col-sm-12">
					<h4><?php echo $message; ?></h4>
					<h4 class="text-center">Add Product</h4>
                    <hr>
					<form action="" method="post" enctype="multipart/form-data">
                        <div class="text-center">
                            <button class="btn btn-primary mb-3" name="add_btn">Add Product</button>
                            <input type="reset" class="btn btn-danger mb-3 mx-5" value="Clear">
                            <a href="admin_dashboard.php" class="btn btn-info mb-3">Go Back</a>
                        </div>

                        <div class="mb-2">
                            <label for="pt" class="form-label">Product Title</label>
                            <input type="text" name="p_name" id="pt" placeholder="Product Title" class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="pq" class="form-label">Product Quantity</label>
                            <input type="number" name="p_qty" id="pq" class="form-control" onkeyup="multi(this.value)">
                        </div>
                        <div class="mb-2">
                            <label for="pc" class="form-label">Product Price</label>
                            <input type="text" name="p_price" id="pc" class="form-control" onkeyup="multi(this.value)">
                        </div>
                        <div class="mb-2">
                            <label for="tp" class="form-label">Total Price</label>
                            <input type="number" name="total_price" id="total_price" class="form-control" value="readonly" aria-label="readonly input example" readonly>
                        </div>
						<div class="mb-2">
                            <label for="tp" class="form-label">Product Image</label>
                            <input type="file" name="p_image" class="form-control" >
                        </div>
						<div class="mb-2">
                            <label for="tp" class="form-label">Product Details</label>
                            <textarea name="p_desc" cols="30" rows="6" class="form-control"></textarea>
                        </div>

                    </form>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12"></div>
			</div>
		</div>
		<!-- Add Product End -->
		
		<!-- show product data start -->
        <div class="container">
            <div class="row">
                <h3 class="text-center text-white bg-primary p-2">PRODUCT DATA FETCH</h3>

                <div class="col-lg-12 col-md-12 col-sm-12">
                  
                    <form action="delete_multiple.php" method="post">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="bg-success">
                                <tr class="text-center">
                                    <th>#</th>
                                    <th>Product Name</th>
                                    <th>Product Quantity</th>
                                    <th>Product Price</th>
                                    <th>Total Price</th>
                                    <th>Product Image</th>
                                    <th>Product Details</th>
                                    <th>Action</th>
                                    <th>
									<button class="btn btn-danger" name="mul_del_btn"
                                            onclick="return confirm('Do You Want To Delete All !')">More-Del</button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- ======= data fetch code start ============ -->
                                <?php

                                $read = "SELECT * FROM product_add ORDER BY id DESC";
                                $query = mysqli_query($connect, $read);
                                
								while($row = mysqli_fetch_array($query)){
                                ?>

                                <tr class="text-center">
                                    <td><?php echo $row['id'] ?></td>
                                    <td><?php echo $row['p_name'] ?></td>
                                    <td><?php echo $row['p_qty'] ?></td>
                                    <td><?php echo $row['p_price'] ?></td>
                                    <td><?php echo $row['total_price'] ?></td>
                                    <td><?php echo $row['p_image'] ?></td>
                                    <td><?php echo $row['p_desc'] ?></td>
                                    <td>
                                        <a class="btn btn-primary"
                                            href="edit_product.php?idNo=<?php echo $row['id'] ?>">Edit</a>
                                        <a class="btn btn-danger" onclick="return confirm('Do You Want To Delete !')"
                                            href="delete.php?idNo=<?php echo $row['id'] ?>">Delete</a>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" name="mul_del_id[]" value="<?php echo $row['id']; ?>">
                                    </td>
                                </tr>

                            <?php
                            }
                            ?>
							
                            </tbody>

                        </table>
                    </form>
                </div>

            </div>
        </div>
        </div>
        <!-- show product data end -->


		<script>
		// auto addition input fields value start
		function multi(value){
			var a = document.getElementById('pq').value; 
			var b = document.getElementById('pc').value;

			var multy = parseFloat(a) * parseFloat(b);
			document.getElementById('total_price').value = parseFloat(multy).toFixed(2);
		}
		// auto addition input fields value end
		
        $(document).ready(function() {
            $('table').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                responsive: true,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search Records",
                }
            });
        });

        //After refresh/reload Data Resubmission Stop with this code
        if (window.history.replaceState) {
            window.history.replaceState(null, null, location.href)
        }
        </script>

        <!-- <script src="bootstrap/js/bootstrap.bundle.min.js"></script> -->
        <script src="admin_dashboard.js"></script>
    </body>
</html>