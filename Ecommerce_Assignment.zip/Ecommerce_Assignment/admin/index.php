<?php
 include_once "db_connect.php";

 if(isset($_SESSION['email'])){
	header("location:admin_dashboard.php");
}

 session_start();
 //error_reporting(0);
 if(isset($_POST['login'])){
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $pass = mysqli_real_escape_string($connect, $_POST['pass']);
    //$email = $_POST['email'];
    //$pass = $_POST['pass'];

    $select = "SELECT * FROM admin_reg WHERE email ='$email' AND password = '$pass'";
    $ex = mysqli_query($connect,$select);

    $fetch = mysqli_fetch_array($ex);

    if($fetch){
      // echo "<script>alert('Login Successful')</script>";
      header('Location: admin_dashboard.php');
      // fetch email address from database to another page display
      $_SESSION['email'] = $fetch['email'];
      // fetch password from database to another page display
      //$_SESSION['password'] = $fetch['password'];
  }
  else{
      echo "<script>alert('Email and Password Not Matched')</script>";
  }


 }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Login</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body class="bg-success">

        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12 bg-warning p-3 mt-5 shadow rounded">
                    <h4 class="text-center">Admin Login</h4>
                    <hr>
                    <form method="post">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" name="email" class="form-control" id="exampleInputEmail1">
                        </div>

                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" name="pass" class="form-control" id="exampleInputPassword1">
                        </div>

                        <button type="submit" name="login" class="btn btn-primary form-control">Log In</button>
                    </form>

                    <a href="admin_register.php" class="btn btn-danger form-control mt-3">Admin Regiatration</a>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>




        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>