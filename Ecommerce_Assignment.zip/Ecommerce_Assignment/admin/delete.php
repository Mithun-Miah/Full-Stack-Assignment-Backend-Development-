<?php
include_once "db_connect.php";

$id = $_GET['idNo'];

$delete = "DELETE FROM product_add WHERE id = $id";
$delQuery = mysqli_query($connect, $delete);

if($delQuery){
    header ("location: add_product.php");
}else{
    echo "<script>alert('Data Delete Fail')</script>";
}
?>