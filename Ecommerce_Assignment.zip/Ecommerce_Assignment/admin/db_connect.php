<?php
$connect = mysqli_connect("localhost", "root", "", "ecommerce_database");
if($connect){
//echo "success";
}else{
    echo "failed";
}
?>