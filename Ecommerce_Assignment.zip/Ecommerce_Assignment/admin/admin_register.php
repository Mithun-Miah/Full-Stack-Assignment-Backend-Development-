<?php
include_once "db_connect.php";

if(isset($_POST['reg_btn'])){
  $name = $_POST['name'];
  $email = $_POST['email'];
  $pass = $_POST['pass'];
  $c_pass = $_POST['c_pass'];

  if(empty($name) || empty($email) || empty($pass) || empty($c_pass)){
    echo "<script>alert('All Fileds are Required...')</script>";
  }else{
    if($pass != $c_pass){
      echo "<script>alert('Password and Confirm Password Not Match...')</script>";
    }else{
      if(strlen($pass) !== 5){
        echo "<script>alert('Password Lenght Must be Five ...')</script>";
      }else{
        $insert = "INSERT INTO admin_reg(name,email,password) VALUES('$name','$email','$pass')";
        $insert_query = mysqli_query($connect, $insert);
        if($insert_query){
          echo "<script>alert('Admin Registration Success...')</script>";
        }else{
          echo "<script>alert('Admin Registration Failed...')</script>";
        }

      }

    }

  }


}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Registration</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body class="bg-success">

        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12 bg-info p-3 mt-2 shadow rounded">
                    <h4 class="text-center">Admin Registration</h4>
                    <hr>
                    <form method="post">
                        <div class="mb-1">
                            <label for="exampleInputName1" class="form-label">Admin Name</label>
                            <input type="text" name="name" class="form-control" id="exampleInputName1">
                        </div>
                        <div class="mb-1">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" name="email" class="form-control" id="exampleInputEmail1">
                        </div>
                        <div class="mb-1">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" name="pass" class="form-control" id="exampleInputPassword1">
                        </div>
                        <div class="mb-1">
                            <label for="exampleInputPassword2" class="form-label">Confirm Password</label>
                            <input type="password" name="c_pass" class="form-control" id="exampleInputPassword2">
                        </div>

                        <button type="submit" name="reg_btn"
                            class="btn btn-primary form-control mt-2">Regiatration</button>
                    </form>

                    <a href="index.php" class="btn btn-danger form-control mt-3">Login</a>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>




        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>