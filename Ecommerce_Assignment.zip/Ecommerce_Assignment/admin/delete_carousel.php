<?php
include_once "db_connect.php";

$id = $_GET['idNo'];

$delete = "DELETE FROM add_carousel WHERE id = $id";
$delQuery = mysqli_query($connect, $delete);

if($delQuery){
    header ("location: add_carousel.php");
}else{
    echo "<script>alert('Data Delete Fail')</script>";
}
?>