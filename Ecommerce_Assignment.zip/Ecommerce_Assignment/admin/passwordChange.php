<?php
// For Store data
session_start();

// if(!isset($_SESSION['email'])){
// 	header("location:index.php");
// }

// Database Connection code Start
include_once "db_connect.php";
// Database Connection code End

// Database table and column name selection code
if(isset($_POST['submit'])){
    // html email and password field selection code
    $email = $_POST['email'];
    $password = $_POST['password']; //old password
    $newpass = $_POST['newpass'];
    $confnewpass = $_POST['confnewpass'];

    $query = mysqli_query($connect, "SELECT email,password from admin_reg where email = '$email' AND password = '$password'");

    $num = mysqli_fetch_array($query);

    if($password == "" || $newpass == "" || $confnewpass == ""){
        echo "<script>alert('Fields Can Not be Empty!')</script>";
    }else{
        if($newpass != $confnewpass){
            echo "<script>alert('New and Confirm Password not match')</script>";
        }else{
            if($num>0){
                $con = mysqli_query($connect, "UPDATE admin_reg set password = '$newpass' where email = '$email' ");

                echo "<script>alert('Password change success')</script>";
            }else{
                echo "<script>alert('Old and New Password does not match')</script>";
            }
        }

    }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Change Password</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        <style>
        body {
            background-color: #2A7CA5;
        }

        .user_box {
            box-shadow: 0px 3px 10px black;
        }
        </style>

    </head>
    <body>

    <?php
        //include 'navbar.php';
    ?>

        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="mb-3 text-end">
                        <a href="admin_dashboard.php" class="btn btn-primary">Go Back</a>
                        <a href="logout.php" class="btn btn-danger">Logout</a>
                    </div>
                    <div class="user_box p-3 rounded bg-light">
                        <form action="" method="POST">
                            <h3 class="text-center py-2 mb-3 bg-secondary text-light">Change Your Password</h3>
                            <input type="email" name="email" value="<?php echo $_SESSION['email'];?>"
                                class="form-control mb-3" readonly>
                            <input type="password" name="password" class="form-control mb-3"
                                placeholder="Enter Old Password">
                            <input type="password" name="newpass" class="form-control mb-3"
                                placeholder="Enter New Password">
                            <input type="password" name="confnewpass" class="form-control mb-3"
                                placeholder="Enter New Password Again">
                            <input type="submit" name="submit" class="btn btn-success d-block text-center mb-3"
                                value="Change Password">

                        </form>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>


        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>