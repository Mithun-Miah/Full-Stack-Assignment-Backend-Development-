<?php
//session_start();

include_once 'db_connect.php';

$id = $_GET['idNo'];

//For Show Data in Edit page input field
$read = "SELECT * FROM add_carousel WHERE id=$id";
$query = mysqli_query($connect, $read);
$row = mysqli_fetch_array($query);

if(isset($_POST['caro_update_btn'])){

    $image_name = $_FILES['caro_image']['name'];
    $tmp_name = $_FILES['caro_image']['tmp_name'];

    $upload = move_uploaded_file($tmp_name, "carousel-image/".$image_name);

    if($upload){
        $update = "UPDATE add_carousel SET carousel_img = '$image_name' where id = $id ";
        $query = mysqli_query($connect, $update);
        if($query){
            echo "<script>alert('Data Update Success')</script>";
        } else{
            echo "<script>alert('Data Update Fail')</script>";
        }
    }else{
        echo "<script>alert('Update Failed !')</script>";
    }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Carousel</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="admin_dashboard.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />

    </head>
    <body>
        <?php include_once "nav_menu.php"; ?>

        <!-- Edit Carousel Start -->
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h4 class="text-center">Edit Carousel</h4>
                    <hr>

                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="text-center">
                            <button class="btn btn-primary mb-3" name="caro_update_btn">Edit Carousel</button>
                            <a href="add_carousel.php" class="btn btn-info mb-3">Go Back</a>
                        </div>

                        <?php
						 if($row['carousel_img'] == ''){
							echo '<img src="images/default_user_icon.png" width="130">';
						 }else{
							echo '<img src="carousel-image/'.$row['carousel_img'].'" width="130">';
						 }

					  ?>

                        <div class="mb-2">
                            <label for="tp" class="form-label">Carousel Image</label>
                            <input type="file" name="caro_image" class="form-control"
                                value="<?php echo $row['carousel_img'] ?>">
                        </div>

                    </form>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>
        <!-- Edit Carousel End -->


        <script>
        //After refresh/reload Data Resubmission Stop with this code
        if (window.history.replaceState) {
            window.history.replaceState(null, null, location.href)
        }
        </script>

        <!-- <script src="bootstrap/js/bootstrap.bundle.min.js"></script> -->
        <!-- <script src="admin_dashboard.js"></script> -->
    </body>
</html>