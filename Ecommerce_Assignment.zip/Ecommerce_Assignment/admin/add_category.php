<?php
// For Store data
session_start();

$message = "";

if(!isset($_SESSION['email'])){
	header("location:index.php");
}

include_once "db_connect.php";

// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h4 class='text-center text-light bg-success py-3'>Email : $_SESSION[email]</h4>");
    //echo("<h1>Password : $_SESSION[password]</h1>");
} else{
    header('Location: index.php');
}

if(isset($_POST['add_btn'])){
    $cat_name = $_POST['cat_name'];

    if($cat_name == ""){
        echo "<script>alert('Fields Are Required...')</script>";
    }else{
        $insert = "INSERT INTO category(cat_name) VALUES('$cat_name')";

        $insert_query = mysqli_query($connect, $insert);

        if($insert_query){
            echo "<script>alert('category Add Success...')</script>";
        }else{
            echo "<script>alert('category Add Failed...')</script>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Add</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="admin_dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
    <!-- data table cdn -->
	<link rel="stylesheet" href="../data_tables_cdn_files/bootstrap.min.css">
    <link rel="stylesheet" href="../data_tables_cdn_files/dataTables.bootstrap5.min.css">

    <script src="../data_tables_cdn_files/jquery-3.6.0.min.js"></script>
    <script src="../data_tables_cdn_files/bootstrap.bundle.min.js"></script>
    <script src="../data_tables_cdn_files/jquery.dataTables.min.js"></script>
    <script src="../data_tables_cdn_files/dataTables.bootstrap5.min.js"></script>
</head>
<body>
    <?php include_once "nav_menu.php"; ?>

    		<!-- Add Product Start -->
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-12"></div>
				
				<div class="col-lg-6 col-md-6 col-sm-12">
					<h4><?php echo $message; ?></h4>
					<h4 class="text-center">Add Category</h4>
                    <hr>
					<form action="" method="post">
                        <div class="text-center">
                            <button class="btn btn-primary mb-3" name="add_btn">Add</button>
                            <input type="reset" class="btn btn-danger mb-3 mx-5" value="Clear">
                            <a href="admin_dashboard.php" class="btn btn-info mb-3">Go Back</a>
                        </div>

                        <div class="mb-2">
                            <label for="pt" class="form-label">Category Name</label>
                            <input type="text" name="cat_name" placeholder="Product Title" class="form-control">
                        </div>
                        
                    </form>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12"></div>
			</div>
		</div>
		<!-- Add Product End -->
		
		<!-- show product data start -->
        <div class="container">
            <div class="row">
                <h3 class="text-center text-white bg-primary p-2">CATEGORY DATA FETCH</h3>

                <div class="col-lg-12 col-md-12 col-sm-12">
                  
                    <form action="delete_multiple.php" method="post">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="bg-success">
                                <tr class="text-center">
                                    <th>#</th>
                                    <th>Category Name</th>
                                    <th>Action</th>
                                    <th>
									<button class="btn btn-danger" name="mul_del_btn"
                                            onclick="return confirm('Do You Want To Delete All !')">More-Del</button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- ======= data fetch code start ============ -->
                                <?php

                                $read = "SELECT * FROM category ORDER BY id DESC";
                                $query = mysqli_query($connect, $read);
                                
								while($row = mysqli_fetch_array($query)){
                                ?>

                                <tr class="text-center">
                                    <td><?php echo $row['id'] ?></td>
                                    <td><?php echo $row['cat_name'] ?></td>

                                    <td>
                                        <a class="btn btn-primary"
                                            href="edit_category.php?idNo=<?php echo $row['id'] ?>">Edit</a>
                                        <a class="btn btn-danger" onclick="return confirm('Do You Want To Delete !')"
                                            href="delete.php?idNo=<?php echo $row['id'] ?>">Delete</a>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" name="mul_del_id[]" value="<?php echo $row['id']; ?>">
                                    </td>
                                </tr>

                            <?php
                            }
                            ?>
							
                            </tbody>

                        </table>
                    </form>
                </div>

            </div>
        </div>
        </div>
        <!-- show product data end -->
    



    <script>
		
        $(document).ready(function() {
            $('table').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                responsive: true,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search Records",
                }
            });
        });

        //After refresh/reload Data Resubmission Stop with this code
        if (window.history.replaceState) {
            window.history.replaceState(null, null, location.href)
        }
    </script>

    <!-- <script src="bootstrap/js/bootstrap.bundle.min.js"></script> -->
    <script src="admin_dashboard.js"></script>
</body>
</html>