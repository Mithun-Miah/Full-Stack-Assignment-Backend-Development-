<?php
// For Store data
session_start();

if(!isset($_SESSION['email'])){
	header("location:index.php");
}
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    //echo("<span class='text-center text-light bg-success py-3'>Email : $_SESSION[email]</span>");
    $email = $_SESSION['email'];
    //echo("<h1>Password : $_SESSION[password]</h1>");
} else{
    header('Location: index.php');
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Dashboard</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="admin_dashboard.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-dark text-light">Admin Dashboard</div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Profile
                        View</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Profile
                        Update</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="passwordChange.php">Password
                        Change</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Total
                        User's</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">User's
                        Update</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="#!"><?php echo $_SESSION['email'] ?></a>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn btn-primary" id="sidebarToggle"><i class="fa-solid fa-bars"></i></button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation"><span
                                class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">

                                <li class="nav-item active"><a class="nav-link" href="admin_dashboard.php">Home</a>
                                </li>

                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Entry
                                        Menu</a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="add_product.php">Add Product</a>
                                        <a class="dropdown-item" href="add_carousel.php">Add Carousel</a>
                                        <a class="dropdown-item" href="add_flash_sale.php">Add Flash Sale</a>
                                        <a class="dropdown-item" href="add_category.php">Category Add</a>
                                    </div>
                                </li>
                                
                                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid">
                    <div class="row">
                        <h4 class="text-center">Total Display of Database Row</h4>
                        <hr>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card border-success mb-3" style="max-width: 18rem;">
                                <div class="card-header bg-transparent border-success">Header</div>
                                <div class="card-body text-success">
                                    <h5 class="card-title">Success card title</h5>
                                    <p class="card-text">Some quick example</p>
                                </div>
                                <div class="card-footer bg-transparent border-success">Footer</div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card border-danger mb-3" style="max-width: 18rem;">
                                <div class="card-header bg-transparent border-danger">Header</div>
                                <div class="card-body text-danger">
                                    <h5 class="card-title">Success card title</h5>
                                    <p class="card-text">Some quick example</p>
                                </div>
                                <div class="card-footer bg-transparent border-danger">Footer</div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card border-warning mb-3" style="max-width: 18rem;">
                                <div class="card-header bg-transparent border-warning">Header</div>
                                <div class="card-body text-dark">
                                    <h5 class="card-title">Success card title</h5>
                                    <p class="card-text">Some quick example</p>
                                </div>
                                <div class="card-footer bg-transparent border-warning">Footer</div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                                <div class="card-header bg-transparent border-primary">Header</div>
                                <div class="card-body text-primary">
                                    <h5 class="card-title">Success card title</h5>
                                    <p class="card-text">Some quick example</p>
                                </div>
                                <div class="card-footer bg-transparent border-primary">Footer</div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card border-info mb-3" style="max-width: 18rem;">
                                <div class="card-header bg-transparent border-info">Header</div>
                                <div class="card-body text-dark">
                                    <h5 class="card-title">Success card title</h5>
                                    <p class="card-text">Some quick example</p>
                                </div>
                                <div class="card-footer bg-transparent border-info">Footer</div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card border-success mb-3" style="max-width: 18rem;">
                                <div class="card-header bg-transparent border-dark">Header</div>
                                <div class="card-body text-dark">
                                    <h5 class="card-title">Success card title</h5>
                                    <p class="card-text">Some quick example</p>
                                </div>
                                <div class="card-footer bg-transparent border-success">Footer</div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->



        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="admin_dashboard.js"></script>
    </body>
</html>