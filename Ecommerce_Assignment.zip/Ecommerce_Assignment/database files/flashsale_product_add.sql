-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2022 at 06:34 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `flashsale_product_add`
--

CREATE TABLE `flashsale_product_add` (
  `id` int(20) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_qty` varchar(100) NOT NULL,
  `p_price` varchar(100) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `p_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `flashsale_product_add`
--

INSERT INTO `flashsale_product_add` (`id`, `p_name`, `p_qty`, `p_price`, `total_price`, `p_image`) VALUES
(1, 'PU Leather Black Analog Watch For Men', '5', '128', '640.00', 'f-watch.jpg'),
(2, 'G20 Gaming Earphone Noise Reduction 3.5mm Gaming Headset with Microphone', '10', '347', '3470.00', 'fs-2.jpg'),
(3, 'HBQ I7S TWS Double Dual Mini Wireless 4.1 Bluetooth Earphone With Power Case - White', '35', '269', '9415.00', 'fs-7.jpg'),
(4, 'NEW Sunglass for Men From Sunglasses BD', '50', '214', '10700.00', 'fs-4.png'),
(5, 'I7S Double Dual Mini Wireless 4.1 Bluetooth Earphone With Power Case - White', '30', '280', '8400.00', 'fs-5.jpg'),
(6, 'Cotton Bra Boil Fabrics Multi-Color 1 Piece', '100', '36', '3600.00', 'fs-6.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `flashsale_product_add`
--
ALTER TABLE `flashsale_product_add`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `flashsale_product_add`
--
ALTER TABLE `flashsale_product_add`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
