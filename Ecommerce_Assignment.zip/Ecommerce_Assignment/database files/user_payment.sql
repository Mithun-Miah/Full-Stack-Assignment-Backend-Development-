-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2022 at 06:34 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_payment`
--

CREATE TABLE `user_payment` (
  `id` int(11) NOT NULL,
  `u_name` varchar(100) NOT NULL,
  `u_email` varchar(100) NOT NULL,
  `u_phone` varchar(100) NOT NULL,
  `u_city` varchar(100) NOT NULL,
  `u_pay` varchar(100) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `total_payment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_payment`
--

INSERT INTO `user_payment` (`id`, `u_name`, `u_email`, `u_phone`, `u_city`, `u_pay`, `p_name`, `total_payment`) VALUES
(1, 'Nasir Hossain', 'nasir@gmail.com', '12345678911', 'Dhaka', '1', '32 Inches Sony Plus TV Smart / Wi-Fi HD LED TV RAM -1GB - ROM - 8GB - 4k supported(1)<p>,Stylish Pre', '32045'),
(2, 'Nasir Hossain', 'nasir@gmail.com', '12345678911', 'Dhaka', 'Nagad', 'Intel Core i3 RAM 4GB HDD 500GB Graphics 2GB Built in Gaming PC(1)<p>,Redmi Computer 1A 23.8(1)', '33690'),
(3, 'Nasir Hossain', 'nasir@gmail.com', '12345678911', 'Dhaka', 'Rocket', 'Stylish Denim Jeans Pant For Men(1)<p></p>Stylish Premium Winter Jacket For Men - White and Navy(1)<', '988'),
(4, 'Nasir Hossain', 'nasir@gmail.com', '12345678911', 'Dhaka', 'Bkash', 'realme Narzo 50A Prime - 4GB RAM / 128GB ROM(1)', '16520'),
(5, 'Nasir Hossain', 'nasir@gmail.com', '12345678911', 'Savar', 'Nagad', 'Intel Core i3 RAM 4GB HDD 500GB Graphics 2GB Built in Gaming PC(1)<p></p>Redmi Computer 1A 23.8(1)', '33690'),
(6, 'Nasir Hossain', 'nasir@gmail.com', '12345678911', '', '', 'realme Narzo 50A Prime - 4GB RAM / 128GB ROM(1)<p></p>WiFi IP Camera V380 IP Camera 360 Degree CCTV ', '32040');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_payment`
--
ALTER TABLE `user_payment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_payment`
--
ALTER TABLE `user_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
