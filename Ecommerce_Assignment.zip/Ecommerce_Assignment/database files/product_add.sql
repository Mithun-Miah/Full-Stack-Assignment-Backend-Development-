-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2022 at 04:45 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `product_add`
--

CREATE TABLE `product_add` (
  `id` int(20) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_qty` varchar(100) NOT NULL,
  `p_price` varchar(100) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `p_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_add`
--

INSERT INTO `product_add` (`id`, `p_name`, `p_qty`, `p_price`, `total_price`, `p_image`) VALUES
(2, 'Intel Core i3 RAM 4GB HDD 500GB Graphics 2GB Built in Gaming PC', '1', '19500', '19500.00', 'monitor.jpg'),
(3, 'Redmi Computer 1A 23.8\" Full HD - Black', '1', '14190', '14190.00', 'computer.png'),
(4, 'realme Narzo 50A Prime - 4GB RAM / 128GB ROM', '1', '16520', '16520.00', 'phone.jpg'),
(5, 'WiFi IP Camera V380 IP Camera 360 Degree CCTV Camera Wireless Mini CC Camera', '2', '1330', '2660.00', 'camera.jpg'),
(6, '32 Inches Sony Plus TV Smart / Wi-Fi HD LED TV RAM -1GB - ROM - 8GB - 4k supported', '5', '11870', '59350.00', 'smart_tv.jpg'),
(7, 'Stylish Denim Jeans Pant For Men', '300', '313', '93900.00', 'man_jeans.jpg'),
(8, 'Stylish Premium Winter Jacket For Men - White and Navy', '30', '547', '16410.00', 'Jacket.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product_add`
--
ALTER TABLE `product_add`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product_add`
--
ALTER TABLE `product_add`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
