-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2022 at 02:27 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `product_add`
--

CREATE TABLE `product_add` (
  `id` int(20) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_qty` varchar(100) NOT NULL,
  `p_price` varchar(100) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `p_image` varchar(255) NOT NULL,
  `p_desc` varchar(1200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_add`
--

INSERT INTO `product_add` (`id`, `p_name`, `p_qty`, `p_price`, `total_price`, `p_image`, `p_desc`) VALUES
(2, 'Intel Core i3 RAM 4GB HDD 500GB Graphics 2GB Built in Gaming PC', '1', '19500', '19500.00', 'monitor.jpg', ''),
(3, 'Redmi Computer 1A 23.8\" Full HD - Black', '1', '14190', '14190.00', 'computer.png', ''),
(4, 'realme Narzo 50A Prime - 4GB RAM / 128GB ROM', '1', '16520', '16520.00', 'phone.jpg', ''),
(5, 'WiFi IP Camera V380 IP Camera 360 Degree CCTV Camera Wireless Mini CC Camera', '2', '1330', '2660.00', 'camera.jpg', ''),
(6, '32 Inches Sony Plus TV Smart / Wi-Fi HD LED TV RAM -1GB - ROM - 8GB - 4k supported', '5', '11870', '59350.00', 'smart_tv.jpg', ''),
(7, 'Stylish Denim Jeans Pant For Men', '300', '313', '93900.00', 'man_jeans.jpg', ''),
(8, 'Stylish Premium Winter Jacket For Men - White and Navy', '30', '547', '16410.00', 'Jacket.jpg', ''),
(9, 'PU Leather Black Analog Watch For Men', '30', '128', '3840.00', 'watch.jpg', ''),
(10, 'Apple iPhone 14 Pro Max (256GB 6GB RAM)', '10', '105000', '1050000.00', 'iphone.jpg', ''),
(11, 'Sundarban Natural Honey (সুন্দরবনের প্রাকৃতিক মধু)', '5', '155', '775.00', 'Sundarban-Natural-Honey-500gm-E.jpg', ''),
(12, 'MOULINEX COFFEE MAKER (FG-360D10)', '10', '4950', '49500.00', 'moulinex-coffee-maker_machine-mk-electronics-001.jpg', ''),
(13, 'SIEMENS DRYER MACHINE (WT46G40SGC) 9.00KGS', '5', '97000', '485000.00', 'mcsa02636872_wt46g40sgc_def.png', ''),
(14, 'Muslim wear Black hijab inner cap for women synthetic soft cotton', '20', '25', '500.00', 'hijab.jpg', 'Product details of Muslim wear Black hijab inner cap for women synthetic soft cotton\nPremium Quality fabrics\nGender:Women\nSoftandcomfortabletowear\nLight-weight\nEasy to Carry\nEasytowearitinEverytimeofPrayer/Namaz\nStylish and Fashionable\nNote:ColormaybeLight/Deepduetodisplaydifferencesinmobile.\n\nPremium Quality fabrics\nGender:Women\nSoftandcomfortabletowear\nLight-weight\nEasy to Carry\nEasytowearitinEverytimeofPrayer/Namaz\nStylish and Fashionable\nNote:ColormaybeLight/Deepduetodisplaydifferencesinmobile.\n\nSpecifications of Muslim wear Black hijab inner cap for women synthetic soft cotton\nBrandNo BrandSKU205247894_BD-1153571264Main MaterialCotton\nWhat’s in the box\n\nমহিলাদের জন্য মুসলিম পরার কালো রঙের হিজাব ইনার ক্যাপ সিনথেটিক সফট সুতি');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product_add`
--
ALTER TABLE `product_add`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product_add`
--
ALTER TABLE `product_add`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
