<?php
// For Store data
session_start();

// Database Connection code Start
include_once "db_connect.php";
// Database Connection code End

$id=$_SESSION['id'];

 //For Show Data in Edit page input field
 $read = "SELECT * FROM user_reg where id='$id'";
 $query = mysqli_query($connect, $read);
 $row = mysqli_fetch_array($query);

// Database table and column name selection code
if(isset($_POST['submit'])){
    // html email and password field selection code
    $u_name = $_POST['u_name'];
    $u_email = $_POST['u_email'];
    $u_phone = $_POST['u_phone'];

    if($u_name == "" || $u_email == "" || $u_phone == ""){
        echo "<script>alert('Fields Can Not be Empty!')</script>";
    }else{
        $updateinfo = "UPDATE user_reg SET u_name = '$u_name', u_email = '$u_email', u_phone = '$u_phone' WHERE id = $id ";

        $query = mysqli_query($connect, $updateinfo);

        if($query){
            echo "<script>alert('Data Update Success')</script>";
        } else{
            echo "<script>alert('Data Update Fail')</script>";
        }
    }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Profile Edit</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        <style>
        body {
            background-color: #2A7CA5;
        }

        .user_box {
            box-shadow: 0px 3px 10px black;
        }
        </style>

    </head>
    <body>

    <?php
        //include 'navbar.php';
    ?>

        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="mb-3 text-end">
                        <a href="user_panel.php" class="btn btn-primary">Go Back</a>
                        <a href="logout.php" class="btn btn-danger">Logout</a>
                    </div>
                    <div class="user_box p-3 rounded bg-light">
                        <form action="" method="POST">
                            <h3 class="text-center py-2 mb-3 bg-secondary text-light">Update Profile</h3>

                            <input type="text" name="u_name" value="<?php echo $row['u_name'];?>" class="form-control mb-3">

                            <input type="email" name="u_email" value="<?php echo $row['u_email'];?>" class="form-control mb-3">

                            <input type="number" name="u_phone" value="<?php echo $row['u_phone'];?>" class="form-control mb-3">
                            
                            <input type="submit" name="submit" class="btn btn-success d-block text-center mb-3" value="Update">

                        </form>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>


        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>