<?php
	include_once 'db_connect.php';

    session_start();

    if($_SESSION['u_email']==true){
        echo "welcome ". $_SESSION['u_email'];
        //$email = $_SESSION['u_email'];
    }else{
        header('Location: index.php');
    }

    $total = 0 ;
    $select = "SELECT * FROM user_order";
    $sel_query = mysqli_query($connect, $select);
    while($row = mysqli_fetch_array($sel_query)){
        //echo "<br>".$product_name[]= $row['p_name'].'('.$row['quantity'].')';
        $product_name[]= $row['p_name'].'('.$row['quantity'].')';
        $product_price = ((int)$row['p_price'] * (int)$row['quantity']);
        $total +=  $product_price;
    }
    //echo $total;
    $impl_convert = implode('<p></p>',$product_name);

    if(isset($_POST['order_confirm_btn'])){
        $u_name = $_POST['u_name'];
        $u_email = $_POST['u_email'];
        $u_phone = $_POST['u_phone'];
        $u_city = $_POST['u_city'];
        $u_pay = $_POST['u_pay'];
        //user_payment

        $insert = "INSERT INTO user_payment(u_name,u_email,u_phone,u_city,u_pay,p_name,total_payment)
        VALUES('$u_name','$u_email','$u_phone','$u_city','$u_pay','$impl_convert','$total')";
        $ex = mysqli_query($connect,$insert);
        if($ex){
            echo "<script>alert('order_confirm ! thank u')</script>";
        }

        $delete = "DELETE FROM user_order";
        $wx = mysqli_query($connect,$delete);

    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order Confirm</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body>

        <?php
          include 'navbar.php';
        ?>

        <div class="container mt-3 mb-5">
            <div class="row">
                <p class="mt-2"> <a href="cart_page.php" class="btn btn-info">Go Back</a></p>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h3 class="text-center">Confirm Your Order</h3>
                    <hr>

                    <?php
                    $select2 = "SELECT * FROM user_reg";
                    $sel_query2 = mysqli_query($connect, $select2);
                    $row = mysqli_fetch_array($sel_query2);
                    ?>
                    <form method="post">
                        <div class="mb-1">
                            <label for="userName1" class="form-label">User Name</label>
                            <input type="text" name="u_name" value="<?php echo $row['u_name']?>" class="form-control"
                                id="userName1">
                        </div>
                        <div class="mb-1">
                            <label for="userEmail1" class="form-label">User Email</label>
                            <input type="email" name="u_email" value="<?php echo $row['u_email']?>" class="form-control"
                                id="userEmail1">
                        </div>
                        <div class="mb-1">
                            <label for="userPhone1" class="form-label">User Phone</label>
                            <input type="text" name="u_phone" value="<?php echo $row['u_phone']?>" class="form-control"
                                id="userPhone1">
                        </div>
                        <div class="mb-1">
                            <label for="userCity1" class="form-label">User City</label>
                            <input type="text" name="u_city" class="form-control" id="userCity1">
                        </div>
                        <div class="my-3">
                            <select class="form-select" name="u_pay" aria-label="Default select example">
                                <option selected disabled>Select Your Payment Option</option>
                                <option value="Bkash">Bkash</option>
                                <option value="Nagad">Nagad</option>
                                <option value="Rocket">Rocket</option>
                            </select>
                        </div>

                        <button type="submit" name="order_confirm_btn" class="btn btn-primary ">Confirm Your
                            Order</button>
                    </form>

                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <!-- <th>#</th> -->
                                <th>Product Name | Quantity</th>
                                <!-- <th>Product Price</th> -->
                                <th>Total</th>
                                <!-- <th>Action</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo $impl_convert ?></td>

                                <td><?php echo $total ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>