<!-- Modal -->
<div class="modal fade" id="userLoginByCart" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">User Signing In</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Log in start -->
                <div class="user_login_box">
                    <form method="">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email
                                address</label>
                            <input type="email" class="form-control" id="exampleInputEmail1">
                        </div>

                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" class="form-control" id="exampleInputPassword1">
                        </div>

                        <button type="submit" class="btn btn-primary form-control">Log
                            In</button>
                    </form>
                </div>
                <!-- Log in end -->
                <p class="mt-2"><span>If you don't have account, please <a href="user_signup.php">Signup
                            Now</a></span></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <!-- <button type="button" class="btn btn-primary">Signing in</button> -->
            </div>
        </div>
    </div>
</div>