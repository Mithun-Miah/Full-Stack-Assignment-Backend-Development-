<?php
	include_once 'db_connect.php';

    if(isset($_POST['u_reg_btn'])){
        $u_name = $_POST['u_name'];
        $u_email = $_POST['u_email'];
        $u_phone = $_POST['u_phone'];
        $u_pass = $_POST['u_pass'];
        $u_con_pass = $_POST['u_con_pass'];

        if(empty($u_name) || empty($u_email) || empty($u_phone) || empty($u_pass) || empty($u_con_pass)){
            echo "<script>alert('All Fileds are Required...')</script>";
        }else{
            if($u_phone >= 11){
                if($u_pass >= 5){
                    if($u_pass != $u_con_pass){
                        echo "<script>alert('Password and Confirm Password Not Match...')</script>";
                    }else{
                        $insert = "INSERT INTO user_reg(u_name,u_email,u_phone,u_pass) VALUES('$u_name','$u_email','$u_phone','$u_pass')";
                        $insert_query = mysqli_query($connect, $insert);
                        if($insert_query){
                            echo "<script>alert('User Registration Success...')</script>";
                        }else{
                            echo "<script>alert('User Registration Failed...')</script>";
                        }
                    }
                }else{
                    echo "<script>alert('Password Lenght Must be Five and More...')</script>";
                }

            }else{
                echo "<script>alert('Phone Number Must be 11 Digit...')</script>";
            }
        }


    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Signup</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        <style>
        body {
            background-color: #B3B6B7;
        }

        .user_signup_box {
            background-color: #308967;
            color: #fff;
            padding: 15px;
            box-shadow: 0px 4px 7px #000;
            border-radius: 10px;
            margin-top: 30px;
        }
        </style>
    </head>
    <body>

        <!-- user signup code start -->
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="user_signup_box">
                        <h4 class="text-center p-2 text-light">User Signing Up</h4>
                        <hr>
                        <!-- User Signup Start -->
                        <form method="post">
                            <div class="mb-1">
                                <label for="userInputName1" class="form-label">User Name</label>
                                <input type="text" name="u_name" class="form-control" id="userInputName1">
                            </div>
                            <div class="mb-1">
                                <label for="userInputEmail1" class="form-label">Email
                                    address</label>
                                <input type="email" name="u_email" class="form-control" id="userInputEmail1">
                            </div>
                            <div class="mb-1">
                                <label for="userInputName1" class="form-label">Phone Number</label>
                                <input type="number" name="u_phone" class="form-control" id="userInputName1">
                            </div>
                            <div class="mb-1">
                                <label for="userInputPassword1" class="form-label">Password</label>
                                <input type="password" name="u_pass" class="form-control" id="userInputPassword1">
                            </div>
                            <div class="mb-1">
                                <label for="userInputPassword2" class="form-label">Confirm
                                    Password</label>
                                <input type="password" name="u_con_pass" class="form-control" id="userInputPassword2">
                            </div>

                            <button type="submit" name="u_reg_btn"
                                class="btn btn-primary form-control mt-2">Regiatration</button>
                        </form>
                        <!-- User Signup End -->
                        <p class="mt-3"> <a href="user_login.php" class="text-warning">Login Here</a></p>
                    </div>

                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>
        <!-- user signup code end -->





        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>