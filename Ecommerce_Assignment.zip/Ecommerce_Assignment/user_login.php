<?php
	include_once 'db_connect.php';

    session_start();

    if(isset($_POST['u_login_btn'])){

    $u_email = $_POST['u_email'];
    $u_pass = $_POST['u_pass'];

    //to prevent from mysqli injection start
    $u_email = stripslashes($u_email);
    $u_pass = stripslashes($u_pass);
    $u_email = mysqli_real_escape_string($connect, $_POST['u_email']);
    $u_pass = mysqli_real_escape_string($connect, $_POST['u_pass']);
    //to prevent from mysqli injection end
    $query =   mysqli_query($connect,"SELECT * FROM user_reg WHERE u_email='$u_email' AND u_pass='$u_pass'");

   $row = mysqli_fetch_array($query);

   if($row){
    $_SESSION['u_name'] = $row['u_name'];
    $_SESSION['u_email'] = $row['u_email'];
    $_SESSION['u_phone'] = $row['u_phone'];
    $_SESSION['id'] = $row['id'];
     header("location:user_panel.php");
   }else{
    echo "<script>alert('Email and Password Not match')</script>";
    //header("location:index.php");
   }

}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Login</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        <style>
        body {
            background-color: #B3B6B7;
        }

        .user_signin_box {
            background-color: #308967;
            color: #fff;
            padding: 15px;
            box-shadow: 0px 4px 7px #000;
            border-radius: 10px;
            margin-top: 30px;
        }
        </style>
    </head>
    <body>

        <!-- user login code start -->
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="user_signin_box">
                        <h4 class="text-center p-2 text-light">User Login</h4>
                        <hr>
                        <!-- Log in start -->

                        <form method="post">
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Email
                                    address</label>
                                <input type="email" name="u_email" class="form-control" id="exampleInputEmail1">
                            </div>

                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Password</label>
                                <input type="password" name="u_pass" class="form-control" id="exampleInputPassword1">
                            </div>

                            <button type="submit" name="u_login_btn" class="btn btn-primary form-control">Log
                                In</button>
                        </form>

                        <!-- Log in end -->
                        <p class="mt-3"> <a href="user_signup.php" class="text-warning">Signup Here</a></p>
                    </div>

                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>
        <!-- user login code end -->



        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>