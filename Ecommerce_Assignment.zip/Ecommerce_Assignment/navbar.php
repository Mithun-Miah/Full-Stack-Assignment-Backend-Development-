<?php
	include_once 'db_connect.php';

    session_start();

?>

<style>
.dropShadow {
    box-shadow: 0px 4px 7px black;
    transition: 0.5s all;
}
</style>

<!-- navbar start -->
<nav class="navbar navbar-expand-lg bg-light" id="navbar_top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><img src="images/logo.jpg" class="img-fluid" width="50" alt="logo"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Category
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Electronics</a></li>
                        <li><a class="dropdown-item" href="#">Man Dress</a></li>
                        <li><a class="dropdown-item" href="#">Woman Dress</a></li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Policy
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Terms and Conditions</a></li>
                        <li><a class="dropdown-item" href="#">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#contact">Contact</a>
                    <!-- Modal -->
                    <div class="modal fade" id="contact" data-bs-backdrop="static" data-bs-keyboard="false"
                        tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="false">
                        <div class="modal-dialog modal-dialog-scrollable">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="staticBackdropLabel">Contact Us</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>

                                <div class="modal-body">
                                    <!-- Log in start -->
                                    <div class="user_login_box">
                                        <form method="">
                                            <div class="mb-3">
                                                <label for="nameInput1" class="form-label">User Name</label>
                                                <input type="text" class="form-control" id="nameInput1">
                                            </div>
                                            <div class="mb-3">
                                                <label for="userInputEmail1" class="form-label">Email
                                                    address</label>
                                                <input type="email" class="form-control" id="userInputEmail1">
                                            </div>

                                            <div class="mb-3">
                                                <label for="subInput1" class="form-label">Subject</label>
                                                <input type="text" class="form-control" id="subInput1">
                                            </div>
                                            <div class="mb-3">
                                                <label for="msgInput1" class="form-label">Message</label>
                                                <textarea name="msgBox" id="msgInput1" cols="30" rows="5"
                                                    class="form-control"></textarea>
                                            </div>

                                            <button type="submit" class="btn btn-primary form-control">Submit</button>
                                        </form>
                                    </div>
                                    <!-- Log in end -->
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                <?php if(isset($_SESSION['u_email'])){ ?>

                    <a class="nav-link" href="cart_page.php">Cart List
                        <?php
                        $sql = "SELECT * FROM user_order";
                        $ex = mysqli_query($connect,$sql);
                        $num = mysqli_num_rows($ex);
                        //echo $num;
                        echo "<span class='text-danger fw-bold'>$num</span>";
                        
                        ?>
                    </a>

                <?php }else{ ?>

                    <a class="nav-link" href="cart_page.php">Cart List
                        <?php
                        $cart_count = 0;
                        echo "<span class='text-danger fw-bold'>$cart_count</span>";
                        ?>
                    </a>

                <?php } ?>

                </li>

            <?php

            if(isset($_SESSION['u_email'])){ ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Account
                    </a>
                    <ul class="dropdown-menu">
                    <li class="nav-item text-center"><?php echo($_SESSION['u_email']); ?></li>
                    <li><a class="dropdown-item" href="user_panel.php">Dashboard</a></li>
                    <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                    </ul>
                </li>
              <li class="nav-item">
                <a class="nav-link text-danger" type="button" href="logout.php">Logout</a>
              </li>

            <?php }else{ ?>

                <li class="nav-item">
                    <a class="nav-link" type="button" href="user_signup.php">Sign Up</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" type="button" href="user_login.php">Sign In</a>
                </li>

            <?php } ?>

            </ul>

        </div>
    </div>
</nav>
<!-- navbar end -->

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            document.getElementById('navbar_top').classList.add('fixed-top');
            // document.getElementById("navbar_top").style.boxShadow = "0px 4px 7px black";
            document.getElementById("navbar_top").classList.add('dropShadow');
            // add padding top to show content behind navbar
            navbar_height = document.querySelector('.navbar').offsetHeight;
            document.body.style.paddingTop = navbar_height + 'px';
        } else {
            document.getElementById('navbar_top').classList.remove('fixed-top');
            document.getElementById("navbar_top").classList.remove('dropShadow');
            // remove padding top from body
            document.body.style.paddingTop = '0';
        }
    });
});
// DOMContentLoaded  end
</script>