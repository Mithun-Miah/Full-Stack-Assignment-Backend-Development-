<?php
	include_once 'db_connect.php';

    if(isset($_POST['cart_btn'])){
        $p_name = $_POST['p_name'];
        $p_price = $_POST['p_price'];
        $p_image = $_POST['p_image'];
        $quantity= 1;
        $insert = "INSERT INTO user_order(p_name,p_price,p_image,quantity)
        VALUES('$p_name','$p_price','$p_image','$quantity')";
        $query = mysqli_query($connect,$insert);

        if($query){
            echo "<script>alert('product add to cart')</script>";
        }
        else{
            echo "<script>alert('product add failed')</script>";
        }

    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="images/favicon.jpg">
        <title>E-Commerce Project</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body>

        <?php
          include 'navbar.php';
        ?>

        <!-- carousel start -->
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true" style="margin-top: 20px;">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">

                <?php
                //For Show Data in Edit page input field
                $select_carousel = "SELECT * FROM add_carousel";
                $caroQuery = mysqli_query($connect, $select_carousel);
                while($rowCaro = mysqli_fetch_array($caroQuery)){ ?>

                <div class="carousel-item active">
                    <img src="admin/carousel-image/<?php echo $rowCaro['carousel_img'] ?>" class="d-block w-100"
                        height="350" alt="image">
                </div>

                <?php
                }
                ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        <!-- carousel end -->

        <!-- search bar start -->
        <div class="container mt-3">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <form class="d-flex" role="search">
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- search bar end -->

        <!-- product display start -->
        <div class="container mt-4 mb-5">
            <div class="row">

                <?php
                //include 'login_modal.php';
                ?>

                <?php
                //For Show Data in Edit page input field
                $read = "SELECT * FROM product_add";
                $query = mysqli_query($connect, $read);
                while($row = mysqli_fetch_array($query)){ ?>
                <div class="col-lg-3 col-md-3 col-sm-12">

                <form action="" method="post">
                    <div class="card shadow my-2" style="height:320px;">
                        <img src="admin/product_image/<?php echo $row['p_image'] ?>"
                                class="card-img-top w-50 h-50 d-block mx-auto" alt="image">
                        <input type="hidden" name="p_image" value="<?php echo $row['p_image'] ?>">
                        <div class="card-body">
                            <h6 class="card-title"><?php echo $row['p_name']; ?></h6>
                            <input type="hidden" name="p_name" value="<?php echo $row['p_name'] ?>">
                            <p class="card-text">Price ৳ <span><?php echo $row['p_price']; ?></span></p>
                            <input type="hidden" name="p_price" value="<?php echo $row['p_price'] ?>">

                            <button class="btn btn-primary" name="cart_btn">Add To Cart</button>
                            <a href="item_details.php?idNo=<?php echo $row['id'] ?>" class="btn btn-warning">View</a>
                        </div>
                    </div>
                </form>

                </div>
                <?php
                }
                ?>

            </div>
        </div>
        <!-- product display end -->

        <!-- flash sale display start -->
        <div class="container mb-5">
            <div class="row">
                <h4>FlashSale</h4>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <h6 class="text-danger">On Sale Now <span class="text-dark ms-5">Ending in</span> <span
                            id="countDownTimer"></span></h6>
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php
                //For Show Data in Edit page input field
                $read = "SELECT * FROM flashsale_product_add";
                $query = mysqli_query($connect, $read);
                while($row = mysqli_fetch_array($query)){ ?>

                    <a href="#" class="btn" style="height:320px; width:200px;">
                        <div class="card border-0 my-1">
                            <img src="admin/flashsale_product_image/<?php echo $row['p_image'] ?>"
                                class="card-img-top d-block mx-auto" alt="image" style="width:150px;">
                            <div class="card-body p-1">
                                <h6 class="card-title text-start"><?php echo $row['p_name']; ?></h6>
                                <p class="card-text text-start">Price ৳ <span><?php echo $row['p_price']; ?></span></p>
                            </div>
                        </div>
                    </a>

                    <?php
                }
                ?>
                </div>
            </div>
        </div>
        <!-- flash sale display end -->

        <!-- Categories display start -->
        <div class="container mb-5">
            <div class="row">
                <h4>Categories</h4>

            </div>
        </div>
        <!-- Categories display end -->



        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="landing_page.js"></script>
        <!-- <script src="bootstrap/js/popper.min.js"></script> -->
    </body>
</html>