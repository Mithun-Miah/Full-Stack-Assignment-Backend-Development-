<?php
include_once 'db_connect.php';

$id = $_GET['idNo'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Details</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>

    <?php
        include 'navbar.php';
    ?>

    <div class="container mt-5">
        <div class="row">
            <?php
            //For Show Data in Edit page input field
            $read = "SELECT * FROM product_add WHERE id=$id";
            $query = mysqli_query($connect, $read);
            $row = mysqli_fetch_array($query);
            ?>

            <div class="col-lg-3 col-md-3 col-sm-12">
            <?php
				// if($row['p_image'] == ''){
				// 	echo '<img src="admin/images/default_user_icon.png" class="img-fluid" width="250">';
				// }else{
				// 	echo '<img src="admin/product_image/'.$row['p_image'].'" class="img-fluid" width="250">';
				// }

                if(isset($_POST['cart_btn'])){
                    $p_name = $_POST['p_name'];
                    $p_price = $_POST['p_price'];
                    $p_image = $_POST['p_image'];
                    $quantity= 1;
                    $insert = "INSERT INTO user_order(p_name,p_price,p_image,quantity)
                    VALUES('$p_name','$p_price','$p_image','$quantity')";
                    $query = mysqli_query($connect,$insert);
            
                    if($query){
                        echo "<script>alert('product add to cart')</script>";
                    }
                    else{
                        echo "<script>alert('product add failed')</script>";
                    }
            
                }
			?>
            
            <form action="" method="post">
            
                <div class="mb-2">
                    <img src="admin/product_image/<?php echo $row['p_image'] ?>"
                                    class="img-fluid" width="250" alt="image">
                    <input type="hidden" name="p_image" value="<?php echo $row['p_image'] ?>">
                </div>
            
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">
                
                    <div class="mb-2">
                        <h5 class="fw-bold"><?php echo $row['p_name']; ?></h5>
                        <input type="hidden" name="p_name" value="<?php echo $row['p_name'] ?>">
                    </div>
                    <div class="my-3">
                        <h6 class="text-primary">Ratings : </h6>
                    </div>
                    <hr>
                    <div class="mb-2">
                        <h5 class="fw-bold"><span class="fw-bold text-danger h3">৳ </span><?php echo $row['p_price']; ?></h5>
                        <input type="hidden" name="p_price" value="<?php echo $row['p_price'] ?>">
                    </div>
                    <hr>
                    <button class="btn btn-primary" name="cart_btn">Add To Cart</button>
            </div>
            </form>

            <div class="col-lg-3 col-md-3 col-sm-12">
                <section class="Delivery">
                    <h6>Delivery</h6>
                    <p>Dhaka, Dhaka North, Banani Road No. 12 - 19</p>
                    <p>Standard Delivery <br> 3 - 6 day(s) -------- ৳ 62</p>
                    <p>Cash on Delivery Available</p>
                </section>
                <section class="Service">
                    <h6>Service</h6>
                    <p>7 Day Return <br> Change of mind available</p>
                    <p>Warranty not available</p>
                </section>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-12 my-4">
                <div class="mb-2">
                    <h4>Product Details</h4>
                    <hr>
                    <p><?php echo $row['p_desc']; ?></p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-12"></div>
        </div>
    </div>
    
</body>
</html>