<?php
$con = mysqli_connect("localhost","root","","web_eco");
session_start();
if( $_SESSION['email']==true){
    echo "welcome". $_SESSION['email'];
}else{
    header("location:login.php");
}


if(isset($_POST['update'])){
    $quantity = $_POST['quantity'];
    $update_id = $_POST['update_id'];

    $update = "UPDATE user_order SET quantity='$quantity' WHERE id ='$update_id'";
    $ex = mysqli_query($con,$update);


}

if(isset($_GET['remove_id'])){
    $id = $_GET['remove_id'];
    $delete = "DELETE FROM user_order WHERE id ='$id'";
    $ex = mysqli_query($con,$delete);
    header("location:cart.php");
}

if(isset($_GET['DeleteALL'])){
    $delete = "DELETE FROM user_order ";
    $ex = mysqli_query($con,$delete);
    header("location:cart.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>
<body>

  <h1>Order Page Your cart</h1>
  
    
       <div class="container">
         <div class="row">
            <table>
                <th>id</th>
                <th>Image</th>
                <th>Price</th>
                <th>quantity</th>
                <th>$grand total</th>
                <th>action</th>

                <tbody>
                    <?php
                    $total = 0;
                      $select = "SELECT * FROM user_order";
                      $ex = mysqli_query($con,$select);
                      while($row=mysqli_fetch_array($ex)){?>
                         <tr>
                         <td><?php echo $row['id'] ?></td>
                          <td><img height="200" width="200" src="admin/<?php echo $row['img'] ?>" alt=""></td>
                          <td><?php echo $row['pr_price'] ?></td>
                          <td>
                            <form action="" method="post">
                                <input max="5" min="1" name="quantity" type="number" value="<?php echo $row['quantity'] ?>">
                                 <input type="hidden" name="update_id" value="<?php echo $row['id'] ?>">
                                <button class="btn btn-success" name="update">update</button>
                            </form>
                          </td>
                          <td>
                             <?php echo $grand_total = ((int)$row['pr_price'] * (int)$row['quantity']) ?>
                          </td>
                          <td><a  onclick ="return confirm('are u sure???')" href="cart.php?remove_id=<?php echo $row['id'] ?>">remove</a>
        
                          </td>
                         </tr>
                        
                      
                   <?php
                     $total +=  $grand_total;
                }
                    ?>
                    <tr>
                        <td> total = <?php echo $total ?></td>
                        <td><a href="cart.php?DeleteALL=">Delete All</a></td>
                        <td><a href="order.php">order</a></td>
                    </tr>
                </tbody>
            </table>

           
         </div>
       </div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>
</html>