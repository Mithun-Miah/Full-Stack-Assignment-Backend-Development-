<?php
$con = mysqli_connect("localhost","root","","web_eco");
session_start();
error_reporting(0);
if( $_SESSION['email']==true){
    echo "welcome". $_SESSION['email'];
}else{
    header("location:login.php");
}
$total = 0 ;
$select = "SELECT * FROM user_order";
$ex = mysqli_query($con,$select);
while($row = mysqli_fetch_array($ex)){
   echo "<br> total items". $product_name[]= $row['pr_title'] . '('.$row['quantity'].')';
   $product_price = ((int)$row['pr_price'] * (int)$row['quantity']);
   $total +=  $product_price;  
}
echo $total;
$impl_covert = implode(',',$product_name);
if(isset($_POST['order'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $town = $_POST['town'];
    $pay = $_POST['pay'];

    $insert = "INSERT INTO payment(name,email,number,town,pay,pr_name,price)
    VALUES('$name','$email','$number','$town','$pay','$impl_covert','$total')";
    $ex = mysqli_query($con,$insert);
    if($ex){
        echo "<script>alert('order_confirm ! thank u')</script>";
    }
    $delete = "DELETE  FROM user_order";
    $wx = mysqli_query($con,$delete);

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>
<body>
   
  
<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <h1>Order </h1>

            <form action="" method="post">
                <input type="text" name="name" class="form-control" placeholder="enter name "> <br>
                <input type="text" name="email"class="form-control" placeholder="enter email "> <br>
                <input type="text" name="number"class="form-control" placeholder="enter phone number  "> <br>
                <input type="text" name="town"class="form-control" placeholder="enter HomeTown  "> <br>
                <select name="pay"class="form-control" id="">
                    <option value="">Bkash</option>
                    <option value="">Nagad</option>
                    <option value="">Rocket</option>
                </select>
               <br>
               <button name="order">confirm order</button>

            </form>
        </div>
        <div class="col-lg-6">

        </div>
    </div>
</div>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>
</html>