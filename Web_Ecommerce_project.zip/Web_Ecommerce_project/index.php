<?php
$con = mysqli_connect("localhost","root","","web_eco");
// session_start();
// if( $_SESSION['email']==true){
//     echo "welcome ". $_SESSION['email'];
// }else{
//     // header("location:index.php");
//     echo "<script>window.location='index.php'</script>";
// }

if(isset($_POST['cart'])){
    $pr_title = $_POST['pr_title'];
    $pr_desc = $_POST['pr_desc'];
    $pr_price = $_POST['pr_price'];
    $img = $_POST['img'];
   $qunatity= 1;
    $insert = "INSERT INTO user_order(pr_title,pr_desc,pr_price,img,quantity)
    VALUES('$pr_title','$pr_desc','$pr_price','$img','$qunatity')";
    $query = mysqli_query($con,$insert);

    if($query){
        echo "<script>alert('product add to cart')</script>";
    }
    else{
        echo "<script>alert('error')</script>";
    }


}


?>
<!doctype html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bootstrap demo</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    </head>

    <body>

        <nav class="navbar navbar-expand-lg bg-primary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Navbar</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="cart.php">cart
                                <?php
                              $sql = "SELECT * FROM user_order";
                              $ex = mysqli_query($con,$sql);
                              $num = mysqli_num_rows($ex);
                              echo $num;
                            ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                Dropdown
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Something else here</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled">Disabled</a>
                        </li>
                        <li class="nav-item me-2">
                            <a href="index.php" target="_blank" class="btn btn-warning">Visit Site</a>
                        </li>
                        <li class="nav-item">
                            <a href="logout.php" class="btn btn-danger">Logout</a>
                            <!-- <a class="nav-link" href="#">Link</a> -->
                        </li>

                    </ul>
                    <form class="d-flex" role="search">
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>
        <br><br><br><br>

        <div class="container">
            <div class="row">
                <?php
      $select = mysqli_query($con,"SELECT * FROM product");
      while($row= mysqli_fetch_array($select)){?>
                <div class="col-lg-3">
                    <form method="post" action="">
                        <div class="card" style="width: 100%; height:400px">
                            <img style="width:100" height="170" src="admin/<?php echo $row['img'] ?>"
                                class="card-img-top" alt="...">
                            <input type="hidden" name="img" value="<?php echo $row['img'] ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $row['pr_title'] ?></h5>
                                <input type="hidden" name="pr_title" value="<?php echo $row['pr_title'] ?>">
                                <p class="card-text"><?php echo $row['pr_desc'] ?></p>
                                <input type="hidden" name="pr_desc" value="<?php echo $row['pr_desc'] ?>">
                                <h5>price:<?php echo $row['pr_price'] ?> bdt</h5>
                                <input type="hidden" name="pr_price" value="<?php echo $row['pr_price'] ?>">
                                <button class="btn btn-primary " name="cart">add to cart</button>
                            </div>
                        </div>
                    </form>
                </div>
                <?php  }


    ?>




            </div>
        </div>




        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
        </script>
    </body>

</html>