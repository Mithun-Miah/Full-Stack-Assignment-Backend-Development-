<?php
$con = mysqli_connect("localhost","root","","web_eco");
session_start();
if( $_SESSION['email']==true){
    echo "welcome ". $_SESSION['email'];
}else{
    header("location:login.php");
}

if(isset($_POST['submit'])){
    $pr_title = $_POST['pr_title'];
    $pr_desc = $_POST['pr_desc'];
    $pr_price = $_POST['pr_price'];
    $img_name = $_FILES['img']['name'];
    $tmp_name = $_FILES['img']['tmp_name'];

    if(move_uploaded_file($tmp_name,$img_name)){
        $ins = "INSERT INTO product (pr_title,pr_desc,pr_price,img)
        VALUES('$pr_title','$pr_desc',' $pr_price','$img_name')";
        $ex = mysqli_query($con,$ins);

        if($ins){
            echo "<script>alert('success')</script>";
        }else{
            echo "failed";
        }
    }else{
        echo "failed";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    </head>
    <body>

        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-4"></div>
                <div class="col-lg-4 col-md-4 col-sm-4"></div>
                <div class="col-lg-4 col-md-4 col-sm-4 text-end">
                    <a href="logout.php" class="btn btn-danger">Logout</a>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label"> product title</label>
                        <input type="text" name="pr_title" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp">
                        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">product description</label>
                        <input type="text" name="pr_desc" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">product price</label>
                        <input type="text" name="pr_price" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">image</label>
                        <input type="file" name="img" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp">
                    </div>

                    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                </form>

            </div>
        </div>

        <div class="container">
            <div class="row">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col"> title</th>
                            <th scope="col"> desc</th>
                            <th scope="col"> price</th>
                            <th scope="col"> img</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
         $sel = "SELECT * FROM product";
         $ex = mysqli_query($con,$sel);
         while($row= mysqli_fetch_array($ex)){?>

                        <tr>
                            <td><?php  echo $row['id']  ?></td>
                            <td><?php  echo $row['pr_title']  ?></td>
                            <td><?php  echo $row['pr_desc']  ?></td>
                            <td><?php  echo $row['pr_price']  ?></td>
                            <td><img height="140" width="120" src="<?php  echo $row['img']  ?>" alt=""></td>

                        </tr>
                        <?php   }

      ?>

                    </tbody>
                </table>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
        </script>
    </body>
</html>