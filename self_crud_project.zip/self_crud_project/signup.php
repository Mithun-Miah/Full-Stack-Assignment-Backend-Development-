<?php
// Database Connection code Start
include_once "db_connect.php";
// Database Connection code End

if(isset($_POST['signup_Btn'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $c_pass = $_POST['c_password'];

    if($name == "" || $email == "" || $password == "" || $c_pass == ""){
        echo "<script>alert('Field Empty Can not allow!')</script>";
    }else{
    // check duplicate email
    $email_check = "SELECT * FROM user_reg where email = '$email' ";
    $query_ex = mysqli_query($connect, $email_check);
    $num_row = mysqli_num_rows($query_ex);

    if($num_row>0){
        echo "<script>alert('email already exist, please try another email')</script>";
    }else{
        if($password==$c_pass){
            // data insert query working
            $insertData = "INSERT INTO user_reg (name, email, password)
            VALUES ('$name', '$email', '$password')";

            $query = mysqli_query($connect, $insertData);
            if($query){
                echo ("<script>alert('Registration Successfully Complete')</script>");
            } else{
                echo ("<script>alert('Registration Failed')</script>");
            }

        }else{
            echo ("<script>alert('Password and Confirm Password Dose Not Match !')</script>");
        }
    }

    }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign UP</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        <style>
        body {
            background-color: #2AA580;
        }
        </style>

    </head>
    <body>

        <div class="container mt-5">

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12 p-3 bg-light rounded shadow">
                    <h3 class="text-center text-dark">Sign Up Page</h3>
                    <hr>
                    <form method="POST">
                        <input type="text" name="name" class="form-control mb-3" placeholder="Enter Name">
                        <input type="email" name="email" class="form-control mb-3" placeholder="Enter Email">
                        <input type="password" name="password" class="form-control mb-3" placeholder="Enter password">
                        <input type="password" name="c_password" class="form-control mb-3"
                            placeholder="Confirm New password">
                        <button name="signup_Btn" class="btn btn-primary form-control mb-3">Sign UP</button>

                        <a href="index.php" class="btn btn-outline-info mt-3">Login</a>

                    </form>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>



        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>