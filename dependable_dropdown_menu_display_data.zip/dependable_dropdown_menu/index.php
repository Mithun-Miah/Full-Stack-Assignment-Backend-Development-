<?php
$connect = mysqli_connect('localhost', 'root', '', 'dependable_dropdown');

if($connect){
    //echo "Conn Success";
}else{
    echo "Conn Fail";
}

$select = "SELECT * FROM country";
$query = mysqli_query($connect,$select);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Dependable Dropdown</title>

    <style>
    .cont {
        text-align: center;
    }

    select {
        background-color: gray;
        color: white;
        font-size: 1.5rem;
        padding: 10px;
        width: 30%;
    }

    h1 {
        background-color: black;
        color: white;
        padding: 10px;
    }
    </style>
</head>

<body>

    <div class="cont">
        <h1>Dependable Dropdown PHP MySQL AJAX</h1>
        <h2>Select Country</h2>
        <select name="" id="country">
            <option value="">Select Country</option>
            <?php 
            while($row = mysqli_fetch_array($query)){ ?>

            <option value="<?php echo $row['id'] ?>"><?php echo $row['country_name'] ?></option>

            <?php
            
            }
            
            ?>

        </select>

        <h2>Select City</h2>
        <div>

            <select name="" id="" class="subDiv">
                <option value="">Select City</option>
            </select>

        </div>


    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="index.js"></script>
</body>

</html>