<?php
//define('MYAPP',true);
// For Store data
session_start();

if(isset($_SESSION['email'])){
	header("location:user_dashboard.php");
}

// Database Connection code Start
include_once "db_connect.php";
// Database Connection code End

// Database table and column name selection code
if(isset($_POST['loginBtn'])){
    // html email and password field selection code
    $email = $_POST['email'];
    $password = $_POST['password'];

    // select database table and column name line
    $select = "SELECT * FROM user_reg WHERE email = '$email' AND password = '$password'";

    // execute code by query
    $execute = mysqli_query($connect, $select);

    // for data Bring up by fetch
    $fetch = mysqli_fetch_array($execute);
    // Condition Apply For check
    if($fetch){
        // echo "<script>alert('Login Successful')</script>";
        header('Location: user_dashboard.php');
        // fetch email address from database to another page display
        $_SESSION['email'] = $fetch['email'];
        // fetch password from database to another page display
        $_SESSION['password'] = $fetch['password'];
    }
    else{
        echo "<script>alert('Email and Password Not Matched')</script>";
    }
}

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login System</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        <style>
        body {
            background-color: #2AA580;
        }

        .user_box {
            background-color: #fff;
            box-shadow: 0px 3px 10px black;
        }
        </style>
    </head>
    <body>

        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="user_box p-3 rounded">
                        <h4 class="text-center text-uppercase">Login System Page with PHP</h4>
                        <hr class="mb-4">
                        <form method="POST">
                            <input type="email" name="email" class="form-control mb-3" placeholder="Enter Email">
                            <input type="password" name="password" class="form-control mb-3"
                                placeholder="Enter password">
                            <button name="loginBtn" class="btn btn-primary d-block mb-3">Login Now</button>

                            <a href="signup.php" class="btn btn-link mt-3">Sign Up Now</a>

                        </form>

                        <!-- <div class="text-end">
                            <a href="forgetPassword.php" class="forgetPass">Forget Password?</a>
                        </div> -->
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>


        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>