<?php
//define('MYAPP',true);
// For Store data
session_start();

if(isset($_SESSION['email'])){
	header("location:user_dashboard.php");
}

// Database Connection code Start
include_once "db_connect.php";
// Database Connection code End

// Database table and column name selection code
if(isset($_POST['loginBtn'])){
    // html email and password field selection code
    $email = $_POST['email'];
    $password = $_POST['password'];

    $select = "SELECT * FROM user_reg WHERE email ='$email'";
    $ex = mysqli_query($connect,$select);

    if(mysqli_num_rows($ex) > 0){
        while($row = mysqli_fetch_array($ex)){
            $pass_verify = password_verify($password,$row['password']);
            //echo $pass_verify;
            if($pass_verify == 1){
                $_SESSION['email']= $row['email'];
                header("location:user_dashboard.php");
            }else{
                echo "<script>alert('Email and Password Not Matched')</script>";
            }
        }
    }else{
        echo "<script>alert('Please Enter Your Correct Details')</script>";
    }

}

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login System</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        <style>
        body {
            background-color: #2AA580;
        }

        .user_box {
            background-color: #fff;
            box-shadow: 0px 3px 10px black;
        }
        </style>
    </head>
    <body>

        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="user_box p-3 rounded">
                        <h4 class="text-center text-uppercase">Login System Page with PHP</h4>
                        <hr class="mb-4">
                        <form method="POST">
                            <input type="email" name="email" class="form-control mb-3" placeholder="Enter Email">
                            <input type="password" name="password" id="pass" class="form-control mb-1"
                                placeholder="Enter password">
                            <input type="checkbox" id="checkbox" class="mb-3"> Show Password
                            <button name="loginBtn" class="btn btn-primary d-block mb-3">Login Now</button>

                            <a href="signup.php" class="btn btn-link mt-3">Sign Up Now</a>

                        </form>

                        <!-- <div class="text-end">
                            <a href="forgetPassword.php" class="forgetPass">Forget Password?</a>
                        </div> -->
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>


        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="app.js"></script>
    </body>
</html>