var checkbox = document.getElementById("checkbox");
    checkbox.addEventListener('click', function() {
		var pass = document.getElementById("pass");
            if (pass.type == "password") {
                pass.type = "text";
            } else {
                pass.type = "password";
            }
        });