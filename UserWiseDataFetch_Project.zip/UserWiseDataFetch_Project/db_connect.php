<?php
$connect = mysqli_connect("localhost", "root", "","self_crud_project");

if($connect){
    // echo "<script>alert('Database Connection Success...')</script>";
}else{
    echo "<script>alert('Database Connection Failed...')</script>";
}
?>