<?php
// For Store data
session_start();

if(!isset($_SESSION['email'])){
	header("location:index.php");
}

// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h4 class='text-center text-light bg-success py-3'>Email : $_SESSION[email]</h4>");
} else{
    header('Location: index.php');
}


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Dashboard</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

        <style>
        body {
            background-color: #2AA580;
        }

        .user_box {
            box-shadow: 0px 3px 10px black;
        }
        </style>
    </head>
    <body>

        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12"></div>

                <div class="col-lg-4 col-md-4 col-sm-12">
                    <a href="logout.php" class="btn btn-danger">Logout</a>
                    <div class="user_box mt-5 text-center bg-secondary p-3 rounded">
                        <h4 class="text-light fw-bold">Welcome To Working Profile Page</h4>
                        <a href="add_product.php" class="btn btn-primary my-3">Product Entry</a>
                        <hr>
                        <h3 class="text-warning py-2 fw-bold">Change Your Password</h3>
                        <a href="passwordChange.php" class="btn btn-info">Password Change</a>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-12"></div>
            </div>
        </div>




        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>