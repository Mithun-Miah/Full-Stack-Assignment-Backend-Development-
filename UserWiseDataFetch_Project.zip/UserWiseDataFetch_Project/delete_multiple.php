<?php
// Database Connection with mysql database
include_once "db_connect.php";

if(isset($_POST['mul_del_btn'])){
    $mul_del_id = $_POST['mul_del_id'];

    $extract = implode("," , $mul_del_id);

    $mul_delete = "DELETE FROM product_post WHERE id IN($extract)";
    $ex = mysqli_query($connect, $mul_delete);

    if($ex){
        echo "<script>alert('Selected Products Delete Success')</script>";
        header("location:add_product.php");
    } else{
        echo "<script>alert('Selected Products Delete Failed')</script>";
        //header("location:index.php");
    }
}
?>