<?php
// For Store data
session_start();

if(!isset($_SESSION['email'])){
	header("location:index.php");
}

// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h4 class='text-center text-light bg-success py-3'>Email : $_SESSION[email]</h4>");
    //echo("<h1>Password : $_SESSION[password]</h1>");
} else{
    header('Location: index.php');
}

include_once "db_connect.php";

// ========= user wide data fetch code start ==============
$user = $_SESSION['email'];
//echo $user;
$u_query = "select * from user_reg where email = '$user'";
$u_queryEx = mysqli_query($connect, $u_query);
$uRow = mysqli_fetch_array($u_queryEx);
//print_r ($uRow);
$user_logId = $uRow['id'];
// ========= user wide data fetch code end ==============

if(isset($_POST['p_name'])){
    $p_name = $_POST['p_name'];
    $p_qty = $_POST['p_qty'];
    $p_price = $_POST['p_price'];
    $total_price = $_POST['total_price'];

    if($p_name == "" || $p_qty == "" || $p_price == "" || $total_price == ""){
        echo "<script>alert('Fields Are Required...')</script>";
    }else{
        $insert = "INSERT INTO product_post(p_name,p_qty,p_price,total_price,user_id)
        VALUES('$p_name', '$p_qty', '$p_price', '$total_price', '$user_logId')";

        $insert_query = mysqli_query($connect, $insert);

        if($insert_query){
            echo "<script>alert('Product Add Success...')</script>";
        }else{
            echo "<script>alert('Product Add Failed...')</script>";
        }

    }
}


?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Add Product</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
		
		<!-- line awesome cdn -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css"/>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/font-awesome-line-awesome/css/all.min.css"/>
		
		<!-- data table cdn -->
		<link rel="stylesheet" href="data_tables_cdn_files/bootstrap.min.css">
        <link rel="stylesheet" href="data_tables_cdn_files/dataTables.bootstrap5.min.css">

        <script src="data_tables_cdn_files/jquery-3.6.0.min.js"></script>
        <script src="data_tables_cdn_files/bootstrap.bundle.min.js"></script>
        <script src="data_tables_cdn_files/jquery.dataTables.min.js"></script>
        <script src="data_tables_cdn_files/dataTables.bootstrap5.min.js"></script>
    </head>
    <body>

        <div class="container">
            <div class="row">
                <h3 class="text-center text-white bg-primary p-2">ADD PRODUCTS</h3>
					<div class="text-end">
                        <a href="logout.php" class="btn btn-danger">Logout</a>
                    </div>
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <div class="col-lg-6 col-md-6 col-sm-12 mt-4">
                    
                    <form action="" method="post">
                        <div class="text-center">
                            <button class="btn btn-primary mb-3" name="add_btn">Add Product</button>
                            <input type="reset" class="btn btn-danger mb-3 mx-5" value="Clear">
                            <a href="user_dashboard.php" class="btn btn-info mb-3">Go Back</a>
                        </div>

                        <div class="mb-2">
                            <label for="pt" class="form-label">Product Title</label>
                            <input type="text" name="p_name" id="pt" placeholder="Product Title" class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="pq" class="form-label">Product Quantity</label>
                            <input type="number" name="p_qty" id="pq" placeholder="Product Quantity"
                                class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="pc" class="form-label">Product Price</label>
                            <input type="number" name="p_price" id="pc" placeholder="Product Price"
                                class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="tp" class="form-label">Total Price</label>
                            <input type="number" name="total_price" id="tp" placeholder="Total Price"
                                class="form-control">
                        </div>

                    </form>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>

        <!-- show product data start -->
        <div class="container">
            <div class="row">
                <h3 class="text-center text-white bg-primary p-2">PRODUCT DATA FETCH</h3>

                <div class="col-lg-12 col-md-12 col-sm-12">
                    
					<!-- search product data start -->
					<form action="search_item.php" method="post">
						<div class="input-group mb-3">
							<input type="search" name="search" placeholder="Search By Product Title"
								class="form-control" aria-describedby="search-addon">
							<button class="input-group-text" name="search_btn" id="search-addon">Search</button>
						</div>
					</form>
					<!-- search product data end -->

                    <form action="delete_multiple.php" method="post">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="bg-success">
                                <tr class="text-center">
                                    <th>#</th>
                                    <th>Product Name</th>
                                    <th>Product Quantity</th>
                                    <th>Product Price</th>
                                    <th>Total Price</th>
                                    <th>Action</th>
                                    <th><button class="btn btn-danger" name="mul_del_btn"
                                            onclick="return confirm('Do You Want To Delete All !')">More-Del</button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- ======= user wide data fetch code start ============ -->
                                <?php

                                $user = $_SESSION['email'];
                                //echo $user;
                                $u_query = "select * from user_reg where email = '$user'";
                                $u_queryEx = mysqli_query($connect, $u_query);
                                $uRow = mysqli_fetch_array($u_queryEx);
                                //print_r ($uRow);
                                $user_logId = $uRow['id'];

                                $read = "SELECT * FROM product_post where user_id = $user_logId ORDER BY id DESC";
                                $query = mysqli_query($connect, $read);
                                $user_rowCount = mysqli_num_rows($query);

                                for($i=1;$user_rowCount >= $i;$i++){
                                    $row = mysqli_fetch_array($query);
                                    ?>
								
                                <!-- 

                                // $search_input = "";

                                // if(isset($_POST['search_btn'])){
                                // $search_input = $_POST['search'];
                                // }

                                // $select_data = "SELECT * FROM product_post WHERE p_name LIKE '%$search_input%' ORDER
                                BY id DESC";
                                // $selQuery = mysqli_query($connect, $select_data);

                                // while($row = mysqli_fetch_array($selQuery)){ -->

                                <tr class="text-center">
                                    <td><?php echo $row['id'] ?></td>
                                    <td><?php echo $row['p_name'] ?></td>
                                    <td><?php echo $row['p_qty'] ?></td>
                                    <td><?php echo $row['p_price'] ?></td>
                                    <td><?php echo $row['total_price'] ?></td>
                                    <td>
                                        <a class="btn btn-primary"
                                            href="edit.php?idNo=<?php echo $row['id'] ?>">Edit</a>
                                        <a class="btn btn-danger" onclick="return confirm('Do You Want To Delete !')"
                                            href="delete.php?idNo=<?php echo $row['id'] ?>">Delete</a>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" name="mul_del_id[]" value="<?php echo $row['id']; ?>">
                                    </td>
                                </tr>

                                <?php
                            }
                            ?>
							
							

                            </tbody>

                        </table>
                    </form>
                </div>

            </div>
        </div>
        </div>
        <!-- show product data end -->


        <script>		
		
        $(document).ready(function() {
            $('table').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                responsive: true,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search Records",
                }
            });
        });

        //After refresh/reload Data Resubmission Stop with this code
        if (window.history.replaceState) {
            window.history.replaceState(null, null, location.href)
        }
        </script>

        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
</html>