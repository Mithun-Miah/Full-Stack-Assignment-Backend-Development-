<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Add Product</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
		
		<!-- line awesome cdn -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css"/>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/font-awesome-line-awesome/css/all.min.css"/>
		
		<!-- data table cdn -->
		<link rel="stylesheet" href="data_tables_cdn_files/bootstrap.min.css">
        <link rel="stylesheet" href="data_tables_cdn_files/dataTables.bootstrap5.min.css">

        <script src="data_tables_cdn_files/jquery-3.6.0.min.js"></script>
        <script src="data_tables_cdn_files/bootstrap.bundle.min.js"></script>
        <script src="data_tables_cdn_files/jquery.dataTables.min.js"></script>
        <script src="data_tables_cdn_files/dataTables.bootstrap5.min.js"></script>
    </head>
    <body>
	
	<?php
// For Store data
/* session_start();

if(!isset($_SESSION['email'])){
	header("location:index.php");
} */

include_once "db_connect.php";

//<!-- ======= search code start ============ -->
$search_input = "";

if(isset($_POST['search_btn'])){
$search_input = $_POST['search'];

if($search_input == ""){
	echo "<script>alert('Field is Required...')</script>";
	header("location:add_product.php");
}else{
	$select_data = "SELECT * FROM product_post WHERE p_name LIKE '%$search_input%' ORDER
	BY id DESC";
	$selQuery = mysqli_query($connect, $select_data);

	while($row = mysqli_fetch_array($selQuery)){?>
					
	<tr class="text-center">
        <td><?php echo $row['id'] ?></td>
        <td><?php echo $row['p_name'] ?></td>
        <td><?php echo $row['p_qty'] ?></td>
        <td><?php echo $row['p_price'] ?></td>
        <td><?php echo $row['total_price'] ?></td>
        <td>
            <a class="btn btn-primary" href="edit.php?idNo=<?php echo $row['id'] ?>">Edit</a>
            <a class="btn btn-danger" onclick="return confirm('Do You Want To Delete !')"
                href="delete.php?idNo=<?php echo $row['id'] ?>">Delete</a>
        </td>
        <td class="text-center">
            <input type="checkbox" name="mul_del_id[]" value="<?php echo $row['id']; ?>">
        </td>
    </tr>

<?php
	}
}
	


}


?>						



        <script>
				
				
        //After refresh/reload Data Resubmission Stop with this code
        if (window.history.replaceState) {
            window.history.replaceState(null, null, location.href)
        }
        </script>
	
    </body>
    </html>
