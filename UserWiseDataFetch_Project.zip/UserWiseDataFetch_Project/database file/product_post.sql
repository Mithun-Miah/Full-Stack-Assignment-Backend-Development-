-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2022 at 09:08 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `self_crud_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `product_post`
--

CREATE TABLE `product_post` (
  `id` int(20) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_qty` varchar(50) NOT NULL,
  `p_price` varchar(50) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `user_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_post`
--

INSERT INTO `product_post` (`id`, `p_name`, `p_qty`, `p_price`, `total_price`, `user_id`) VALUES
(13, 'BASKET FRENCH FRIES REGULAR 1 PCS', '1', '80', '80', 1),
(14, 'BASKET SQUID MEAT KG', '1', '920', '920', 1),
(15, 'BASKET RED POA 01 (ONE) KG', '1', '420', '420', 2),
(16, 'BD CHANACHUR', '3', '20', '60', 1),
(17, 'CORIANDER POWDER 100 GM', '5', '30', '150', 1),
(18, 'BASKET CHICKEN BURGER CHEESE REGULAR 1 PCS', '2', '150', '300', 1),
(19, 'BASKET SIDES CHICKEN NUGGETS 3 PCS,FRENCH FRIES', '2', '160', '320', 2),
(20, 'BASKET SIDES FRIED CHICKEN,FRENCH FRIES AND COLESLAW SALAD', '2', '230', '460', 2),
(21, 'BASKET CHICKEN SHAWARMA 1 PCS', '5', '90', '450', 2),
(22, 'BASKET CHICKEN SANDWICH 1 PCS', '3', '60', '180', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product_post`
--
ALTER TABLE `product_post`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product_post`
--
ALTER TABLE `product_post`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
