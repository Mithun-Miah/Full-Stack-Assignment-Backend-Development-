<?php
// For Store data
session_start();

if(!isset($_SESSION['email'])){
	header("location:index.php");
}

// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h4 class='text-center text-light bg-success py-3'>Email : $_SESSION[email]</h4>");
    //echo("<h1>Password : $_SESSION[password]</h1>");
} else{
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Data</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body>

        <div class="container">
            <div class="row">
                <h3 class="text-center text-white bg-info p-2">UPDATE PRODUCTS</h3>
				<div class="text-end">
                    <a href="logout.php" class="btn btn-danger">Logout</a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12"></div>

                <?php
                include_once "db_connect.php";

                $id = $_GET['idNo'];

                $select = "SELECT * FROM product_post WHERE id = $id";
                $selQuery = mysqli_query($connect, $select);
                $row = mysqli_fetch_array($selQuery);

                if(isset($_POST['edit_btn'])){
                    $p_name = $_POST['p_name'];
                    $p_qty = $_POST['p_qty'];
                    $p_price = $_POST['p_price'];
                    $total_price = $_POST['total_price'];

                    $update = "UPDATE product_post SET p_name='$p_name', p_qty='$p_qty', p_price='$p_price', total_price='$total_price' WHERE id=$id";
                    $updQuery = mysqli_query($connect, $update);

                    if($updQuery){
                        echo "<script>alert('Product Update Success...')</script>";
                    }else{
                        echo "<script>alert('Product Update Failed')</script>";
                    }

                }

                ?>

                <div class="col-lg-6 col-md-6 col-sm-12 mt-4">
                    
                    <form action="" method="post">
                        <button class="btn btn-primary mb-3 me-5" name="edit_btn">Update Product</button>
                        <a href="add_product.php" class="btn btn-outline-info mb-3">Go Back</a>

                        <div class="mb-2">
                            <label for="pt" class="form-label">Product Title</label>
                            <input type="text" name="p_name" value="<?php echo $row['p_name'] ?>" id="pt"
                                class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="pq" class="form-label">Product Quantity</label>
                            <input type="number" name="p_qty" value="<?php echo $row['p_qty'] ?>" id="pq"
                                class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="pc" class="form-label">Product Price</label>
                            <input type="number" name="p_price" value="<?php echo $row['p_price'] ?>" id="pc"
                                class="form-control">
                        </div>
                        <div class="mb-2">
                            <label for="tp" class="form-label">Total Price</label>
                            <input type="number" name="total_price" value="<?php echo $row['total_price'] ?>" id="tp"
                                class="form-control">
                        </div>

                    </form>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12"></div>
            </div>
        </div>

    </body>
</html>