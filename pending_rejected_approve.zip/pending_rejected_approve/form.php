<?php  
 //Database connectivity  
 $con=mysqli_connect('localhost','root','','tutorials');  
 
 if(isset($_POST['submit_btn']))
 {
	$name = $_POST['name'];
	
	$sql=mysqli_query($con,"insert into login(username) values('$name')");
	
	if($sql)
	{
		echo "<script>alert('Data Sent Success')</script>";
	}else{
		echo "<script>alert('Data Sent Failed')</script>";
	}
 }
 ?>
 
 <?php  
 //Database connectivity  
 //$con=mysqli_connect('localhost','root','','tutorials');  
 $sql=mysqli_query($con,"select * from login");  
 //Get Update id and status  
 if (isset($_GET['id']) && isset($_GET['status'])) {  
      $id=$_GET['id'];  
      $status=$_GET['status'];  
      mysqli_query($con,"update login set status='$status' where id='$id'");  
      header("location:index.php");  
      die();  
 }  
 ?> 
 
 
 <!DOCTYPE html>  
 <html>  
 <head>  
      <meta charset="utf-8">  
      <meta name="viewport" content="width=device-width, initial-scale=1">  
      <title>Form Submit</title> 
	  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
 </head>  
 <body>  
	 <div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			
			<div class="col-lg-6">
				<h3 class="text-center py-2 bg-secondary text-light">Send Data</h3>
				<form method="post">
					<input type="text" name="name" placeholder="Enter Name" class="form-control mb-3" required>
					<!-- <input type="email" name="email" placeholder="Enter Name" class="form-control mb-3">
					<input type="text" name="subj" placeholder="Enter Name" class="form-control mb-3">-->
					<input type="submit" name="submit_btn" value="Submit" class="btn btn-primary">
				</form>
			</div>
			
			<div class="col-lg-3"></div>
		</div>
	 </div>
	 
	  <div class="container my-4">  
      <table class="table border">  
           <tr class="bg-secondary text-light">  
                <th>Sl. No.</th>  
                <th>Username</th>  
                <th>Date Time</th>  
                <th>Status</th>  
           </tr>  
           <?php  
           $i=1;  
           if (mysqli_num_rows($sql)>0) {  
                 while ($row=mysqli_fetch_assoc($sql)) { ?>  
                 <tr>  
                      <td><?php echo $i++ ?></td>  
                      <td><?php echo $row['username'] ?></td>  
                      <td><?php echo $row['added_on'] ?></td>  
                      <td>  
                           <?php  
                           if ($row['status']==1) {  
                                echo "<p class='text-warning fw-bold'>Pending</p>";  
                           }if ($row['status']==2) {  
                                echo "<p class='text-success fw-bold'>Accept</p>";  
                           }if ($row['status']==3) {  
                                echo "<p class='text-danger fw-bold'>Reject</p>";  
                           }  
                           ?>  
                      </td>  

                 </tr>       
           <?php      }  
            } ?>  
      </table>  
 </div>  
  
 </body>  
 </html>  