# PHP & MySQL Ecommerce

Online store written with PHP and MySQL database with admin section.

Access the admin section : 
```
URL : your-domain/admin/
Email : admin@gmail.com
Password : admin
```

## Screenshots
![alt text](screenshot/index.png)
![alt text](screenshot/admin.png)