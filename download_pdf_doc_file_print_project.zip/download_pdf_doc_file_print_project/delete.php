<?php

    // Database Connection with mysql database
    $connect = mysqli_connect("localhost", "root", "", "image");

    $id = $_GET['idNo'];
    $image = $_GET['image_pic'];

    //For Show Data in Delete page input field
    $delete = "DELETE FROM img_upload WHERE Id = $id";
    $query = mysqli_query($connect, $delete);
    
    if($query){
        unlink("image_folder/$image"); // Image Folder and Image pic location for Delete code method
        header("location:image_insert.php");
    } else{
        echo "<script>alert('Data Delete Fail')</script>";
    }

?>