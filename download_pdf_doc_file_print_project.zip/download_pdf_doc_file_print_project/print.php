<?php
$connect = mysqli_connect('localhost', 'root', '', 'image');

$id = $_GET['idNo'];
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Print</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  
	<h3 class="text-center my-2 bg-success text-light">Profile Report</h3>
	
		<div class="text-center py-3">
			<a href="image_insert.php" class="btn btn-primary">Go Back</a>
			<button class="btn btn-success mx-3" onclick="downloadPDF()">Download PDF</button>
			<button class="btn btn-warning mx-3" onclick="downloadDOC()">Download DOC</button>
			<button class="btn btn-info" onclick="display()" id="p_btn">Print</button>
		</div>
	
        <div class="container" id="print_page">
			<div class="row">
				<div class="col-lg-2 col-md-2 col-sm-12"></div>
				
				<div class="col-lg-8 col-md-8 col-sm-12">
				
					<div class="text-center py-3">
						<h4>Print Your Report</h4>
						<hr>
					</div>
				
					<table class="table table-bordered">
						<thead class="text-center">
							<th>Id</th>
							<th>Name</th>
							<th>Phone</th>
							<th>Image</th>
						</thead>
						<tbody class="text-center">
							<?php
							
							$select = "SELECT * FROM img_upload WHERE Id=$id";
							$query = mysqli_query($connect, $select);

							while($row = mysqli_fetch_array($query)){ ?>

							<!-- while loop body -->

							<tr>
								<td><?php echo $row['Id'] ?></td>
								<td><?php echo $row['name'] ?></td>
								<td><?php echo $row['phone'] ?></td>
								<td><img src="image_folder/<?php echo $row['image'] ?>" height="100" width="100" alt=""></td>
							</tr>

							<?php 
							}
							?>
						</tbody>
					</table>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-12"></div>
			</div>
		</div>
  
  
	<script>
		function display(){
			//var p_btn = document.getElementById('p_btn');
			window.print();
			//p_btn.style.display = "none";
		}
		
		function downloadPDF(){
			const print_page = document.getElementById('print_page');
			html2pdf()
				.from(print_page)
				.save();
		}
		
		function downloadDOC(){
			var header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' "+
            "xmlns:w='urn:schemas-microsoft-com:office:word' "+
            "xmlns='http://www.w3.org/TR/REC-html40'>"+
            "<head><meta charset='utf-8'><title>Export HTML to Word Document with JavaScript</title></head><body>";
		   var footer = "</body></html>";
		   var print_page = header+document.getElementById("print_page").innerHTML+footer;
		   
		   var source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(print_page);
		   var fileDownload = document.createElement("a");
		   document.body.appendChild(fileDownload);
		   fileDownload.href = source;
		   fileDownload.download = 'document.doc';
		   fileDownload.click();
		   document.body.removeChild(fileDownload);
		}
	</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/html2pdf.bundle.js"></script>
  </body>
</html>